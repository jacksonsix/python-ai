#leap frog copy

old=[]
new=[]

ofree = 0
nfree = 0

for x in range(100):
    old.append('*')
    new.append('*')


def create_node(c):
    global ofree
    global old
    node =[]
    node.append(c)
    node.append(None)
    old[ofree] = node
    ofree += 2
    return ofree -2

def connect(prev,cur):
    global old
    p = old[prev]
    p[1] = cur
    
def create(*arg):
    global ofree
    i = 0
    nxt = None
    head = ofree
    prev =0
    while i < len(arg):
        c = arg[i]
        addr = create_node(c)
        if i ==0:
            head = addr
        else:    
            connect(prev,addr)
        prev = addr
        i += 1
    return head

def display(index):
    n = old[index]
    print(n[0])
    if n[1] is not None:
        display(n[1])
    
def dumpold():
    global old
    l = len(old)
    for x in range(l):
        print(old[x])
        
def dumpnew():
    global new
    l = len(new)
    for x in range(l):
        print(new[x])    
        

def compact_copy(start):
    global old
    global new
    global nfree
    global ofree

    i = start
    head = nfree
    while i is not None:
        n = old[i]
        i = n[1]
        if n[1] is not None:
            n[1] = nfree + 1
        new[nfree] = n
        nfree += 1

    t = old
    old = new
    new = t
    nfree = 0
    ofree = 0
    return head
