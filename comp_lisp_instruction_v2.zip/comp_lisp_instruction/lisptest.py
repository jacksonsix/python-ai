#lisptest

import compiler as comp

import comp_lisp_instruction as asm


def checkseq(s):
    r1 = s.get('needs')
    r2 = s.get('modifies')
    r3 = s.get('stms')

    print('needs: ')
    if r1 is not None:
        for i1 in r1:
            print(i1)
    print('modify: ')        
    if r2 is not None:
        for i1 in r2:
            print(i1)
    print('stmts: ')        
    if r3 is not None:
        for i1 in r3:
            print(i1)

def test1():
    comp.compile(['self','3'],'','')


def test2():
    c ='(if a 1)'
    m = asm.make_nodes(c)
    for ea in m:
        print(ea)
    ac = asm.make_command(c)
    for a in ac:
        print(a)

def test_comp3():
    cmd =' abc'
    inst = asm.make_command(cmd)
    print(inst)
    s = comp.compile(inst,'val','return')
    checkseq(s)
    
def test_comp4():
    cmd ='(set! a  6)'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','lab1')
    checkseq(s)

def test_comp5():
    cmd ='(define a 6)'
    inst = asm.make_command(cmd)
    print(inst)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_comp6():
    cmd ='(define a \'1.567)'
    inst =  asm.make_command(cmd)
    for i in inst:
        print(i)
def test_if():
    cmd = '(if 3 v 4)'
    inst =  asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_comp7():
    cmd ='(define a \'1.567)'
    inst =  asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_begin():
    cmd='(begin (define b \'abc) (define c 4))'
    inst =  asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_lambda():
    cmd='(lambda() (define a 3))'
    inst =  asm.make_command(cmd)
    print(inst)

def test_define_lambda():
    cmd='(define (add x y) (+ x y))'
    inst =  asm.make_command(cmd)
    print(inst)
import comp_code_gen as gen
def test_seqence():
    def test_s1():
        f = gen.make_empty_sequence()
        print(f)

    def test_s2():
        m1 = gen.make_inst_sequence(['env'],['val'],['(label a)'])
        m2 = gen.make_inst_sequence(['env'],['argl'],['(label b)'])
        p = gen.parallel_seq(m1,m2)
        print(p)

    def test_s3():
        m1 = gen.make_inst_sequence(['env'],['val'],['(label a)'])
        m2 = gen.make_inst_sequence(['env'],['argl'],['(label b)'])
        p = gen.append_seq(m1,m2)
        print(p)

    def test_s4():
        m1 = gen.make_inst_sequence(['env'],['env','val'],['(label a)'])
        m2 = gen.make_inst_sequence(['env','val'],['argl'],['(label b)'])
        p = gen.preserve(['env','val'],m1,m2)
        print(p)

    def test_s5():
        m1 = gen.make_inst_sequence(['env'],['env','val'],['(label a)'])
        m2 = gen.make_inst_sequence(['env','val'],['argl'],['(label b)'])
        p = gen.preserve(['val'],m1,m2)
        print(p)
        
    test_s1()
    test_s2()
    test_s3()
    test_s4()
    test_s5()
    
#test_begin()
#test_comp7()
#test_if()

test_define_lambda()
