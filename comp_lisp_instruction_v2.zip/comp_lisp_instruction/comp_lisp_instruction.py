#basic insturctions

#(test (op =) (reg n) (const 1))
#(branch (label base-case)

#(assign n (op -) (reg n) (const 1))

# (goto (label fact-loop))

 #extend with stack
# (save n)
# (restore n)

#command is list, first member is operation
#everythin inside a () is within a command  operation and oprands
#process with type.  test,branch ...
# process recursive,first , rest
#process into struct node.
 

comlist={'if','cond','self','define'
         ,'variable','lambda','begin'
         ,'set!'}

consts=set()
# get tokens

def pushdown(st):
    i =0;
    level=0
    stack=[]
    word=''
    while i < len(st):
        ch = st[i]
        if ch =='(':
            if len(word.strip()) > 0:
                stack.append(str(level)+ ':'+ word)
            word =''
            level += 1
            stack.append(str(level) +':'+'(')
        elif ch ==')':
            if len(word.strip()) > 0:
                stack.append(str(level)+ ':'+ word)
            word =''
            stack.append(str(level) + ':' +')')           
            level -= 1
        elif ch ==' ' or ch =='\t':
            if len(word.strip()) > 0:
                stack.append(str(level)+ ':'+ word)
            word=''
            while i < len(st):
                if st[i] != ' ' and st[i]!='\t':
                   break
                i += 1
            i -= 1     
        else:
           word += ch

        i += 1
    return stack        


def make_nodes(text):
    s = pushdown(text)
    wordlist=[]
    word=''
    for el in s:
        ss=el.split(':')
        i = int(ss[0])
        
        if i == 1:
            if len(word)>0:
                wordlist.append(word)
                word=''
            wordlist.append(ss[1])
        else:
            word +=' ' +ss[1]
            if ss[1] ==')':
                wordlist.append(word)
                word=''
            
    wordlist = wordlist[1:]
    wordlist = wordlist[:-1]
    return wordlist 
            
def make_command(cmdstring):
     command=[]
     t = make_nodes(cmdstring)
     if len(t) ==0:
          return t
     
     op = t[0]
     oprands = t[1:]
     global comlist
     if len(t) ==1:
          command.extend(primary(op))
     elif(op in comlist):
          command.append(op)
          for para in oprands:
               if(para.find('(') ==-1):
                    cmd = primary(para)
                    command.append(cmd)
               else:
                    incom=make_command(para)
                    command.append(incom)
            
     else:
         command=notkeyword(t)
     
     return command


def primary(t):
     command=[]
     if t[0] == "'":
          command.extend(['quote',t[1:]])
     elif t[0] in ['0','1','2','3','4','5','6','7','8','9']:
          command.extend(['self',t])
     else:
          command.extend(['variable',t])
     return command 
          


def notkeyword(t):
     op=t[0]
     oprands = t[1:]
     command=[]
     command.append('application')
     command.append(['variable',op])
     for para in oprands:
          if(para.find('(') ==-1):
               cmd = primary(para)
               command.append(cmd)
          else:
               incom=make_command(para)
               command.append(incom)
     return command           



def statics_code(codes):
     insts=[]
     labels=dict()
     scanlabel(codes,insts,labels)
     gotoset=set()
     assignset=set()
     stackset=set()
     registers=set()
     libs=set()
     nodes=set()
     edges=set()
     
     for it in insts:
          evt = it[0]
          its =listtostr(it)
          
          if evt =='assign':
               assignset.add(its)
               i2= it[2]
               if i2[0] =='op':
                    libs.add(its)
          elif evt == 'goto':
               gotoset.add(its)
          elif evt =='save' or evt =='restore':
               stackset.add(its)
          elif evt =='perform':
               libs.add(its)
          elif evt == 'test':
               i1= it[1]
               if i1[0] == 'op':
                    libs.add(its)

     keys=[]
     for it in insts:
          keys.append(listtostr(it))
          
     for a in assignset:
          i = keys.index(a)
          stm= insts[i]
          registers.add(stm[1])
          to =stm[1]
          fr = stm[2]
          if fr[0] =='op':
               fr = fr[1]
               edges.add(fr+ '->'+to+','+fr+','+to+','+str(i))
     for g in gotoset:
          i= keys.index(g)
          stm = insts[i]

     for s in stackset:
          i=keys.index(s)
          stm = insts[i]
          registers.add(stm[1])
          if stm[0] =='save':
               edges.add(stm[1]+'->stack,'+stm[1]+',stack'+','+str(i))
          else:
               edges.add('stack->' + stm[1]+',stack,'+stm[1]+','+str(i))

     for l in libs:
          i = keys.index(l)
          stm = insts[i]
          if stm[0] == 'assign':
               op = stm[2:]
          elif stm[0] == 'test':
               op = stm[1:]
               
          opname = op[0][1]
          oprands =op[1:]
          for opd in oprands:
               if opd[0] == 'reg':
                    nodes.add('reg,'+opd[1])
                    edges.add(opd[1]+'->'+opname+','+opd[1]+','+opname+','+str(i))
          nodes.add('op,'+opname)

     for r in registers:     
          nodes.add('reg,'+r)



     result = dict()
     result['reg']= registers
     result['edges']= edges
     result['nodes']= nodes
     return result

def listtostr(lt):
     lstr=''

     if type(lt) is list:
          for i in lt:
               lstr += listtostr(i)
     elif lt is None:
	       lstr +=''
     else:
               lstr += str(lt)
     return lstr    

##from graphviz import Digraph
##def machine_view(codes):
##     result = statics_code(codes)
##     edges = result['edges']
##     nodes = result['nodes']
##     f = Digraph('reg_machine', filename='regm.gv')
##     f.attr(rankdir='LR', size='8,5')
##     f.attr('node', shape='circle')
##     for n in nodes:
##          ns = n.split(',')
##          if ns[0] == 'reg':
##               f.node(ns[1],ns[1],shape='egg')
##          elif ns[0] =='op':
##               f.node(ns[1],ns[1],shape='box')
##          
##     for ed in edges:
##          eds = ed.split(',')
##          f.edge(eds[1],eds[2],label=eds[3])
##
##     f.view()

def log_static():
     f=open('C:/_dev/PythonTest/log.txt',"r")
     st=dict()
     
     for line in f:
          ls = line.split(':')
          nm = ls[2].strip()
          v= st.get(nm)
          if v is None:
               st[nm]=1
          else:
               st[nm] = v+1
               
     for d in st:
          print(d +': ' + str(st[d]))
          
