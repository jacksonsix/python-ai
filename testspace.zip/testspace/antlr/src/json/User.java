package json;

import java.io.FileInputStream;
import java.io.IOException;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class User {
   public static void main(String[] args) throws IOException {
	   testjckson();
		
	   
   }

	private static void testjson() throws IOException {
		//ANTLRInputStream input = new ANTLRInputStream(new FileInputStream("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql")); 
		   CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\json\\test.json");
		   // parse
	        JsonLexer lexer = new JsonLexer(is);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			JsonParser parser = new JsonParser(tokens);
			ParseTree tree = parser.exp();
			
			System.out.println(tree.toStringTree(parser));
			//Env global = new Env();
			int len = tree.getChildCount();
			for(int i=0;i<len;i++) {
				//GenExpression<IIExpression> gen = new GenExpression<IIExpression>();
				//IIExpression exp = (IIExpression) gen.visit(tree.getChild(i));
				//ParseTreeWalker walker = new ParseTreeWalker();
				//walker.walk(new ShortConvert(), tree);
				//Object o =Try.interpret(exp,global);
				//System.out.println("next expression");
			}
	}
	
	private static void testjckson() throws IOException {
		//ANTLRInputStream input = new ANTLRInputStream(new FileInputStream("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql")); 
		   CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\json\\test1.json");
		   // parse
	        JcksnLexer lexer = new JcksnLexer(is);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			JcksnParser parser = new JcksnParser(tokens);
			ParseTree tree = parser.exp();
			
			System.out.println(tree.toStringTree(parser));
			//Env global = new Env();
			int len = tree.getChildCount();
			for(int i=0;i<len;i++) {
				//GenExpression<IIExpression> gen = new GenExpression<IIExpression>();
				//IIExpression exp = (IIExpression) gen.visit(tree.getChild(i));
				//ParseTreeWalker walker = new ParseTreeWalker();
				//walker.walk(new ShortConvert(), tree);
				//Object o =Try.interpret(exp,global);
				//System.out.println("next expression");
			}
	}
}