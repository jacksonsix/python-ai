// Generated from C:\_dev\testspace\antlr\src\json\Json.g4 by ANTLR 4.8
package json;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link JsonParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface JsonVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link JsonParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(JsonParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonParser#member}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMember(JsonParser.MemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonParser#pair}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPair(JsonParser.PairContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonParser#name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitName(JsonParser.NameContext ctx);
	/**
	 * Visit a parse tree produced by {@link JsonParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(JsonParser.ValueContext ctx);
}