// Generated from C:\_dev\testspace\antlr\src\json\Jcksn.g4 by ANTLR 4.8
package json;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link JcksnParser}.
 */
public interface JcksnListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link JcksnParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(JcksnParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(JcksnParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link JcksnParser#member}.
	 * @param ctx the parse tree
	 */
	void enterMember(JcksnParser.MemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#member}.
	 * @param ctx the parse tree
	 */
	void exitMember(JcksnParser.MemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link JcksnParser#pair}.
	 * @param ctx the parse tree
	 */
	void enterPair(JcksnParser.PairContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#pair}.
	 * @param ctx the parse tree
	 */
	void exitPair(JcksnParser.PairContext ctx);
	/**
	 * Enter a parse tree produced by {@link JcksnParser#name}.
	 * @param ctx the parse tree
	 */
	void enterName(JcksnParser.NameContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#name}.
	 * @param ctx the parse tree
	 */
	void exitName(JcksnParser.NameContext ctx);
	/**
	 * Enter a parse tree produced by {@link JcksnParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(JcksnParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(JcksnParser.ValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link JcksnParser#array}.
	 * @param ctx the parse tree
	 */
	void enterArray(JcksnParser.ArrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link JcksnParser#array}.
	 * @param ctx the parse tree
	 */
	void exitArray(JcksnParser.ArrayContext ctx);
}