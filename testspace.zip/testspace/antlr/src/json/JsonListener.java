// Generated from C:\_dev\testspace\antlr\src\json\Json.g4 by ANTLR 4.8
package json;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link JsonParser}.
 */
public interface JsonListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link JsonParser#exp}.
	 * @param ctx the parse tree
	 */
	void enterExp(JsonParser.ExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonParser#exp}.
	 * @param ctx the parse tree
	 */
	void exitExp(JsonParser.ExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonParser#member}.
	 * @param ctx the parse tree
	 */
	void enterMember(JsonParser.MemberContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonParser#member}.
	 * @param ctx the parse tree
	 */
	void exitMember(JsonParser.MemberContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonParser#pair}.
	 * @param ctx the parse tree
	 */
	void enterPair(JsonParser.PairContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonParser#pair}.
	 * @param ctx the parse tree
	 */
	void exitPair(JsonParser.PairContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonParser#name}.
	 * @param ctx the parse tree
	 */
	void enterName(JsonParser.NameContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonParser#name}.
	 * @param ctx the parse tree
	 */
	void exitName(JsonParser.NameContext ctx);
	/**
	 * Enter a parse tree produced by {@link JsonParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(JsonParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link JsonParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(JsonParser.ValueContext ctx);
}