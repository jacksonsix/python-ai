// Generated from C:\_dev\testspace\antlr\src\json\Jcksn.g4 by ANTLR 4.8
package json;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link JcksnParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface JcksnVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link JcksnParser#exp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExp(JcksnParser.ExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link JcksnParser#member}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMember(JcksnParser.MemberContext ctx);
	/**
	 * Visit a parse tree produced by {@link JcksnParser#pair}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPair(JcksnParser.PairContext ctx);
	/**
	 * Visit a parse tree produced by {@link JcksnParser#name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitName(JcksnParser.NameContext ctx);
	/**
	 * Visit a parse tree produced by {@link JcksnParser#value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitValue(JcksnParser.ValueContext ctx);
	/**
	 * Visit a parse tree produced by {@link JcksnParser#array}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArray(JcksnParser.ArrayContext ctx);
}