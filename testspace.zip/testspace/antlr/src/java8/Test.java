package java8;


import java.io.FileInputStream;
import java.io.IOException;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

public class Test {
   public static void main(String[] args) throws IOException {
	   
		test2();
	   
   }
   
   private static void test1() throws IOException {
	 //ANTLRInputStream input = new ANTLRInputStream(new FileInputStream("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql")); 
	   CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\java8\\SimpleCode.java");
	   // parse
        Java8Lexer lexer = new Java8Lexer(is);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		Java8Parser parser = new Java8Parser(tokens);
		ParseTree tree = parser.compilationUnit();
		
		System.out.println(tree.toStringTree(parser));
		//Env global = new Env();
		int len = tree.getChildCount();
		for(int i=0;i<len;i++) {
			//GenExpression<IIExpression> gen = new GenExpression<IIExpression>();
			//IIExpression exp = (IIExpression) gen.visit(tree.getChild(i));
			//ParseTreeWalker walker = new ParseTreeWalker();
			//walker.walk(new ShortConvert(), tree);
			//Object o =Try.interpret(exp,global);
			//System.out.println("next expression");
		}
   }
   
   private static void test2() throws IOException {
	    CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\java8\\SimpleCode.java");
        Java8Lexer lexer = new Java8Lexer(is);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		Java8Parser parser = new Java8Parser(tokens);
		ParseTree tree = parser.compilationUnit();
		//
		ParseTreeWalker walker = new ParseTreeWalker();
		UppercaseMethodListener listener= new UppercaseMethodListener();
		walker.walk(listener, tree);
		 
		//assertThat(listener.getErrors().size(), is(1));
		int s = listener.getErrors().size();
		System.out.println(s);
   }
}
