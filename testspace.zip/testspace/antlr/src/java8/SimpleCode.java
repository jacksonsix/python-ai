package java8;

import java.io.IOException;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

import sql.SqlBaseLexer;
import sql.SqlBaseParser;

public class SimpleCode {
	   public static void main(String[] args) throws IOException {
		   //ANTLRInputStream input = new ANTLRInputStream(new FileInputStream("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql")); 
		   CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql");
		   // parse
	        SqlBaseLexer lexer = new SqlBaseLexer(is);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			SqlBaseParser parser = new SqlBaseParser(tokens);
			ParseTree tree = parser.singleStatement();
			
			System.out.println(tree.toStringTree(parser));
			//Env global = new Env();
			int len = tree.getChildCount();
			for(int i=0;i<len;i++) {
				//GenExpression<IIExpression> gen = new GenExpression<IIExpression>();
				//IIExpression exp = (IIExpression) gen.visit(tree.getChild(i));
				//ParseTreeWalker walker = new ParseTreeWalker();
				//walker.walk(new ShortConvert(), tree);
				//Object o =Try.interpret(exp,global);
				//System.out.println("next expression");
			}
			
		   
	   }
	   
	   public void Test() {
		   
	   }
}
