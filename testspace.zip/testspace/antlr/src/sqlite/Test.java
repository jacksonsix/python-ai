package sqlite;


import java.io.FileInputStream;
import java.io.IOException;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class Test {
   public static void main(String[] args) throws IOException {
	   //ANTLRInputStream input = new ANTLRInputStream(new FileInputStream("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql")); 
	   CharStream is = (CharStream) CharStreams.fromFileName("C:\\_dev\\testspace\\antlr\\src\\sql\\test.sql");
	   // parse
        SQLiteLexer lexer = new SQLiteLexer(is);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		SQLiteParser parser = new SQLiteParser(tokens);
		ParseTree tree = parser.parse();
		
		System.out.println(tree.toStringTree(parser));
		//Env global = new Env();
		int len = tree.getChildCount();
		for(int i=0;i<len;i++) {
			//GenExpression<IIExpression> gen = new GenExpression<IIExpression>();
			//IIExpression exp = (IIExpression) gen.visit(tree.getChild(i));
			//ParseTreeWalker walker = new ParseTreeWalker();
			//walker.walk(new ShortConvert(), tree);
			//Object o =Try.interpret(exp,global);
			//System.out.println("next expression");
		}
		
	   
   }
}
