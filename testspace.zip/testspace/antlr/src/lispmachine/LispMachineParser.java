// Generated from C:\_dev\testspace\antlr\src\lispmachine\LispMachine.g4 by ANTLR 4.8
package lispmachine;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class LispMachineParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, OP=4, LETTER=5;
	public static final int
		RULE_machine = 0, RULE_expression = 1, RULE_controllerExp = 2, RULE_labelExp = 3, 
		RULE_instructExp = 4, RULE_op = 5, RULE_oprand = 6, RULE_strname = 7;
	private static String[] makeRuleNames() {
		return new String[] {
			"machine", "expression", "controllerExp", "labelExp", "instructExp", 
			"op", "oprand", "strname"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "'controller'", "')'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, "OP", "LETTER"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "LispMachine.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public LispMachineParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class MachineContext extends ParserRuleContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public MachineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_machine; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterMachine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitMachine(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitMachine(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MachineContext machine() throws RecognitionException {
		MachineContext _localctx = new MachineContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_machine);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(17); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(16);
				expression();
				}
				}
				setState(19); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 || _la==LETTER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ControllerExpContext controllerExp() {
			return getRuleContext(ControllerExpContext.class,0);
		}
		public LabelExpContext labelExp() {
			return getRuleContext(LabelExpContext.class,0);
		}
		public InstructExpContext instructExp() {
			return getRuleContext(InstructExpContext.class,0);
		}
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterExpression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitExpression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitExpression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		ExpressionContext _localctx = new ExpressionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_expression);
		try {
			setState(24);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(21);
				controllerExp();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(22);
				labelExp();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(23);
				instructExp();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ControllerExpContext extends ParserRuleContext {
		public List<LabelExpContext> labelExp() {
			return getRuleContexts(LabelExpContext.class);
		}
		public LabelExpContext labelExp(int i) {
			return getRuleContext(LabelExpContext.class,i);
		}
		public List<InstructExpContext> instructExp() {
			return getRuleContexts(InstructExpContext.class);
		}
		public InstructExpContext instructExp(int i) {
			return getRuleContext(InstructExpContext.class,i);
		}
		public ControllerExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_controllerExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterControllerExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitControllerExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitControllerExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ControllerExpContext controllerExp() throws RecognitionException {
		ControllerExpContext _localctx = new ControllerExpContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_controllerExp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(26);
			match(T__0);
			setState(27);
			match(T__1);
			setState(30); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(30);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case LETTER:
					{
					setState(28);
					labelExp();
					}
					break;
				case T__0:
					{
					setState(29);
					instructExp();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(32); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 || _la==LETTER );
			setState(34);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LabelExpContext extends ParserRuleContext {
		public StrnameContext strname() {
			return getRuleContext(StrnameContext.class,0);
		}
		public LabelExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_labelExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterLabelExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitLabelExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitLabelExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LabelExpContext labelExp() throws RecognitionException {
		LabelExpContext _localctx = new LabelExpContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_labelExp);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(36);
			strname();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InstructExpContext extends ParserRuleContext {
		public OpContext op() {
			return getRuleContext(OpContext.class,0);
		}
		public List<OprandContext> oprand() {
			return getRuleContexts(OprandContext.class);
		}
		public OprandContext oprand(int i) {
			return getRuleContext(OprandContext.class,i);
		}
		public InstructExpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_instructExp; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterInstructExp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitInstructExp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitInstructExp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InstructExpContext instructExp() throws RecognitionException {
		InstructExpContext _localctx = new InstructExpContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_instructExp);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(38);
			match(T__0);
			setState(39);
			op();
			setState(41); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(40);
				oprand();
				}
				}
				setState(43); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 || _la==LETTER );
			setState(45);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OpContext extends ParserRuleContext {
		public TerminalNode OP() { return getToken(LispMachineParser.OP, 0); }
		public OpContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_op; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterOp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitOp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitOp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OpContext op() throws RecognitionException {
		OpContext _localctx = new OpContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_op);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			match(OP);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OprandContext extends ParserRuleContext {
		public InstructExpContext instructExp() {
			return getRuleContext(InstructExpContext.class,0);
		}
		public StrnameContext strname() {
			return getRuleContext(StrnameContext.class,0);
		}
		public OprandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_oprand; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterOprand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitOprand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitOprand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OprandContext oprand() throws RecognitionException {
		OprandContext _localctx = new OprandContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_oprand);
		try {
			setState(51);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__0:
				enterOuterAlt(_localctx, 1);
				{
				setState(49);
				instructExp();
				}
				break;
			case LETTER:
				enterOuterAlt(_localctx, 2);
				{
				setState(50);
				strname();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StrnameContext extends ParserRuleContext {
		public List<TerminalNode> LETTER() { return getTokens(LispMachineParser.LETTER); }
		public TerminalNode LETTER(int i) {
			return getToken(LispMachineParser.LETTER, i);
		}
		public StrnameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_strname; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).enterStrname(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof LispMachineListener ) ((LispMachineListener)listener).exitStrname(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof LispMachineVisitor ) return ((LispMachineVisitor<? extends T>)visitor).visitStrname(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StrnameContext strname() throws RecognitionException {
		StrnameContext _localctx = new StrnameContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_strname);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(54); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(53);
					match(LETTER);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(56); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\7=\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\3\2\6\2\24\n\2\r\2"+
		"\16\2\25\3\3\3\3\3\3\5\3\33\n\3\3\4\3\4\3\4\3\4\6\4!\n\4\r\4\16\4\"\3"+
		"\4\3\4\3\5\3\5\3\6\3\6\3\6\6\6,\n\6\r\6\16\6-\3\6\3\6\3\7\3\7\3\b\3\b"+
		"\5\b\66\n\b\3\t\6\t9\n\t\r\t\16\t:\3\t\2\2\n\2\4\6\b\n\f\16\20\2\2\2<"+
		"\2\23\3\2\2\2\4\32\3\2\2\2\6\34\3\2\2\2\b&\3\2\2\2\n(\3\2\2\2\f\61\3\2"+
		"\2\2\16\65\3\2\2\2\208\3\2\2\2\22\24\5\4\3\2\23\22\3\2\2\2\24\25\3\2\2"+
		"\2\25\23\3\2\2\2\25\26\3\2\2\2\26\3\3\2\2\2\27\33\5\6\4\2\30\33\5\b\5"+
		"\2\31\33\5\n\6\2\32\27\3\2\2\2\32\30\3\2\2\2\32\31\3\2\2\2\33\5\3\2\2"+
		"\2\34\35\7\3\2\2\35 \7\4\2\2\36!\5\b\5\2\37!\5\n\6\2 \36\3\2\2\2 \37\3"+
		"\2\2\2!\"\3\2\2\2\" \3\2\2\2\"#\3\2\2\2#$\3\2\2\2$%\7\5\2\2%\7\3\2\2\2"+
		"&\'\5\20\t\2\'\t\3\2\2\2()\7\3\2\2)+\5\f\7\2*,\5\16\b\2+*\3\2\2\2,-\3"+
		"\2\2\2-+\3\2\2\2-.\3\2\2\2./\3\2\2\2/\60\7\5\2\2\60\13\3\2\2\2\61\62\7"+
		"\6\2\2\62\r\3\2\2\2\63\66\5\n\6\2\64\66\5\20\t\2\65\63\3\2\2\2\65\64\3"+
		"\2\2\2\66\17\3\2\2\2\679\7\7\2\28\67\3\2\2\29:\3\2\2\2:8\3\2\2\2:;\3\2"+
		"\2\2;\21\3\2\2\2\t\25\32 \"-\65:";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}