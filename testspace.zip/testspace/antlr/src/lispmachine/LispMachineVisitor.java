// Generated from C:\_dev\testspace\antlr\src\lispmachine\LispMachine.g4 by ANTLR 4.8
package lispmachine;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link LispMachineParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface LispMachineVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#machine}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMachine(LispMachineParser.MachineContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(LispMachineParser.ExpressionContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#controllerExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitControllerExp(LispMachineParser.ControllerExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#labelExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLabelExp(LispMachineParser.LabelExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#instructExp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInstructExp(LispMachineParser.InstructExpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#op}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOp(LispMachineParser.OpContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#oprand}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOprand(LispMachineParser.OprandContext ctx);
	/**
	 * Visit a parse tree produced by {@link LispMachineParser#strname}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStrname(LispMachineParser.StrnameContext ctx);
}