// Generated from C:\_dev\testspace\antlr\src\lispmachine\LispMachine.g4 by ANTLR 4.8
package lispmachine;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link LispMachineParser}.
 */
public interface LispMachineListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#machine}.
	 * @param ctx the parse tree
	 */
	void enterMachine(LispMachineParser.MachineContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#machine}.
	 * @param ctx the parse tree
	 */
	void exitMachine(LispMachineParser.MachineContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(LispMachineParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(LispMachineParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#controllerExp}.
	 * @param ctx the parse tree
	 */
	void enterControllerExp(LispMachineParser.ControllerExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#controllerExp}.
	 * @param ctx the parse tree
	 */
	void exitControllerExp(LispMachineParser.ControllerExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#labelExp}.
	 * @param ctx the parse tree
	 */
	void enterLabelExp(LispMachineParser.LabelExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#labelExp}.
	 * @param ctx the parse tree
	 */
	void exitLabelExp(LispMachineParser.LabelExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#instructExp}.
	 * @param ctx the parse tree
	 */
	void enterInstructExp(LispMachineParser.InstructExpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#instructExp}.
	 * @param ctx the parse tree
	 */
	void exitInstructExp(LispMachineParser.InstructExpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#op}.
	 * @param ctx the parse tree
	 */
	void enterOp(LispMachineParser.OpContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#op}.
	 * @param ctx the parse tree
	 */
	void exitOp(LispMachineParser.OpContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#oprand}.
	 * @param ctx the parse tree
	 */
	void enterOprand(LispMachineParser.OprandContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#oprand}.
	 * @param ctx the parse tree
	 */
	void exitOprand(LispMachineParser.OprandContext ctx);
	/**
	 * Enter a parse tree produced by {@link LispMachineParser#strname}.
	 * @param ctx the parse tree
	 */
	void enterStrname(LispMachineParser.StrnameContext ctx);
	/**
	 * Exit a parse tree produced by {@link LispMachineParser#strname}.
	 * @param ctx the parse tree
	 */
	void exitStrname(LispMachineParser.StrnameContext ctx);
}