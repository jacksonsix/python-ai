package log;

import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;


public class Test {
	
	public static void main(String[] args) {
		test1();
	}
	
	public static void test1() {
		
		String logLine ="2018-May-05 14:20:24 ERROR Bad thing happened\n";
		CharStream is = (CharStream) CharStreams.fromString(logLine);
		   // parse
	        LogLexer lexer = new LogLexer(is);
			CommonTokenStream tokens = new CommonTokenStream(lexer);
			LogParser parser = new LogParser(tokens);
			ParseTree tree = parser.log();
			ParseTreeWalker walker = new ParseTreeWalker();
	    // instantiate the lexer, the parser, and the walker
		    MyLogListener listener = new MyLogListener();
		    walker.walk(listener, tree);
		    LogEntry entry = listener.getEntries().get(0);
		    
		    System.out.println(entry.getLevel().toString());
	  
	    //assertThat(entry.getLevel(), is(LogLevel.ERROR));
	    //assertThat(entry.getMessage(), is("Bad thing happened"));
	    //assertThat(entry.getTimestamp(), is(LocalDateTime.of(2018,5,5,14,20,24)));
	}

}
