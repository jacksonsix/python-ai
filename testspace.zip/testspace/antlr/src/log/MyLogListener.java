package log;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MyLogListener  extends LogBaseListener{
	private List<LogEntry> entries = new ArrayList<>();
    private LogEntry current;
    
    @Override
    public void enterEntry(LogParser.EntryContext ctx) {
        this.current = new LogEntry();
    }
    
    @Override
    public void enterTimestamp(LogParser.TimestampContext ctx) {
    	SimpleDateFormat   dateFormatter = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss");
        try {
			this.current.setTimestamp( dateFormatter.parse(ctx.getText()));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
     
    @Override
    public void enterMessage(LogParser.MessageContext ctx) {
        this.current.setMessage(ctx.getText());
    }
     
    @Override
    public void enterLevel(LogParser.LevelContext ctx) {
        this.current.setLevel(LogLevel.valueOf(ctx.getText()));
    }
    
    @Override
    public void exitEntry(LogParser.EntryContext ctx) {
        this.entries.add(this.current);
    }

	public List<LogEntry> getEntries() {
		return entries;
	}

	public void setEntries(List<LogEntry> entries) {
		this.entries = entries;
	}

	public LogEntry getCurrent() {
		return current;
	}

	public void setCurrent(LogEntry current) {
		this.current = current;
	}
    
    
}
