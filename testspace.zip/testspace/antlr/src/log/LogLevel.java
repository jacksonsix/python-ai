package log;

public enum LogLevel {
	ERROR,
	INFO,
	DEBUG
}
