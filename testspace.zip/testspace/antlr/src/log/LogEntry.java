package log;

import java.time.LocalDateTime;
import java.util.Date;

public class LogEntry {
    private LogLevel level;
    private String message;
    private Date timestamp;
    
    
	public LogLevel getLevel() {
		return level;
	}
	public void setLevel(LogLevel level) {
		this.level = level;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date date) {
		this.timestamp = date;
	}
    
    
}
