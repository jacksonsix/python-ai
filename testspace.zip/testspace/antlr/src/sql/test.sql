SELECT * FROM schema1.table1;
