package blockingqueque;

public class User {
	
	BlockingQueue que = new BlockingQueue(5);
	
	public static void main(String[] args) throws InterruptedException {
		BlockingQueue que = new BlockingQueue(5);
		
		
		Producer pro = new Producer(que);
		
		BlockingQueue q = pro.getQue();
		q.enqueue("1");
		q.enqueue("2");
		q.enqueue("3");
		q.enqueue("4");
		q.enqueue("5");
		
		//System.out.println(Thread.getId());
		
		Thread thread1 = new Thread(pro);
		System.out.println(thread1.getState());
		thread1.start();
		
		System.out.println("t1"+thread1.getState());
		
		//que.dequeue();
		
		
		
		Consumer con = new Consumer(que);
		
		Thread t2 = new Thread(con);
		
		t2.start();
		System.out.println("t1"+thread1.getState());
		System.out.println("t2 "+t2.getState());
		
	}

}
