package blockingqueque;

public class Producer  implements Runnable{

	BlockingQueue que;
	
	public Producer(BlockingQueue que) {
		this.que = que;
	}

	public BlockingQueue getQue() {
		return que;
	}

	public void setQue(BlockingQueue que) {
		this.que = que;
	}

	@Override
	public void run() {
		try {
			que.enqueue("6");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
