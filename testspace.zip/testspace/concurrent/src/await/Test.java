package await;


import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static com.jayway.awaitility.Awaitility.await;
import static java.util.concurrent.TimeUnit.SECONDS;

public class Test {
    static volatile boolean done = false;

    public static void main(String[] args) {
        testWithAwaitility();
    }

    private static void testWithAwaitility() {
        System.out.println("start " + new Date());
        new Thread(new Runnable(){
            public void run(){
                try {
                	System.out.println("first instance bore sleep");
                    Thread.sleep(5000);
                    System.out.println("first instance after sleep");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                done = true;
            }

        }).start();


        try {
            await().atMost(2, SECONDS).until(new Callable() {
                @Override
                public Boolean call() throws Exception {
                	System.out.println("second instance");
                    return done;
                }
            });
        } catch (Exception e) {
            System.out.println("FAILED");
            e.printStackTrace();
        }


        System.out.println("end " + new Date());   // REACHED this statement after correction
    }
 }