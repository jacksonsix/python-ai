package statemachine.order;

import org.springframework.stereotype.Service;

import statemachine.ProcessData;
import statemachine.Processor;
import statemachine.ProcessException;

@Service
public class OrderProcessor implements Processor {
    @Override
    public ProcessData process(ProcessData data) throws ProcessException{   
        ((OrderData)data).setEvent(OrderEvent.orderCreated); 
        return data;
    }
}
