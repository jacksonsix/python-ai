package statemachine.order;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import statemachine.ProcessData;
import statemachine.ProcessEvent;

@NoArgsConstructor
@AllArgsConstructor
@Setter @Getter
@Builder
public class OrderData implements ProcessData {
	private double payment;
	private ProcessEvent event;
	private UUID orderId;
	@Override
	public ProcessEvent getEvent() {
		return this.event;
	}
	@Override
	public void setEvent(ProcessEvent evt) {
		this.event = evt;
		
	}
	public double getPayment() {
		return payment;
	}
	public void setPayment(double payment) {
		this.payment = payment;
	}
	public UUID getOrderId() {
		return orderId;
	}
	public void setOrderId(UUID orderId) {
		this.orderId = orderId;
	}
	
}
