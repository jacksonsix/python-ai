package statemachine;

public interface ProcessState {
}
