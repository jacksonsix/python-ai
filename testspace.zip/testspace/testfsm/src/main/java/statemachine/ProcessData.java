package statemachine;

public interface ProcessData {
    public ProcessEvent getEvent();
    public void setEvent(ProcessEvent evt);
}
