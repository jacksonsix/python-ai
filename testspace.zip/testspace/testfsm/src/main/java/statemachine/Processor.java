package statemachine;

public interface Processor {
    public ProcessData process(ProcessData data) throws ProcessException;
}
