#code gen
import comp_lisp_instruction as asm
import compiler 

def make_inst_sequence(needs,modifies,stms):
    result=dict()
    result['needs']=needs
    result['modifies']=modifies
    result['stms']=stms
    return result

def make_empty_sequence():
    result=dict()
    result['needs']=[]
    result['modifies']=[]
    result['stms']=[]
    return result


########################################-----------------------
label_count=0

def make_label(name):
    global label_count
    lname = name+'_'+str(label_count)
    r ='(label {0})'.format(lname)
    label_count += 1
    return r

def preserve(regs,s1,s2):
    r1 = s1.get('needs')
    r2 = s1.get('modifies')
    r3 = s1.get('stms')

    r4 = s2.get('needs')
    r5 = s2.get('modifies')
    r6 = s2.get('stms')

    setn = set(r4)
    setm= set(r2)
    setn.intersection_update(setm)
    saves=[]
    restores=[]
    for s in regs:
        if s in setn:
            saves.append('(save {0})'.format(s))
            restores.insert(0,'(restore {0})'.format(s))
    

    r1.extend(r4)
    r2.extend(r5)

    need=[]
    modify=[]
    sneed=set(r1)
    smod=set(r2)
    need.extend(sneed)
    modify.extend(smod)

    stmtcode=[]
    stmtcode.extend(saves)
    stmtcode.extend(r3)
    stmtcode.extend(restores)
    stmtcode.extend(r6)
       
    r = make_inst_sequence(need,modify,stmtcode)
    return r 

def parallel_seq(s1,s2):
    r1 = s1.get('needs')
    r2 = s1.get('modifies')
    r3 = s1.get('stms')

    r4 = s2.get('needs')
    r5 = s2.get('modifies')
    r6 = s2.get('stms')

    r1.extend(r4)
    r2.extend(r5)
    need = set(r1)
    mod = set(r2)

    n=[]
    n.extend(need)
    m=[]
    m.extend(mod)
    r3.extend(r6)
    
    stm = make_inst_sequence(n, m,r3)
    return stm


def append_seq(s1,s2):
    r1 = s1.get('needs')
    r2 = s1.get('modifies')
    r3 = s1.get('stms')

    r4 = s2.get('needs')
    r5 = s2.get('modifies')
    r6 = s2.get('stms')

    r2.extend(r5)
    r3.extend(r6)

    s4 = set(r4)
    s2= set(r2)
    s4.difference(s2)
    
    r1.extend(s4)

    needed = set(r1)
    modified = set(r2)
    
    inn=[]
    imm=[]
    inn.extend(needed)
    imm.extend(modified)

    return make_inst_sequence(inn,imm,r3)
    
def compile_linkage(link):
    result=None
    if link =='return':
        result = make_inst_sequence(['continue']
                                        ,[]
                                        ,['(goto (reg continue))'])
    elif link =='next':
        result = make_empty_sequence()
    else:
        result = make_inst_sequence([]
                                        ,[]
                                        ,['(goto (label {0}))'.format(link)])
   
    return result    

def end_with_link(link,sequence):
    return preserve(['continue']
             ,sequence
             ,compile_linkage(link))

##########################---------------------------
##########################---------------------------

def compile_self(exp,target,linkage):

    intseq = make_inst_sequence([]
                                ,[target]
                                ,['(assign {0} (const {1}))'.format(target,exp[1])])
    code = end_with_link(linkage,intseq)
    return code
    
def compile_quote(exp,target,linkage):
    intseq = make_inst_sequence([]
                                ,[target]
                                ,['(assign {0} (const  {1}))'.format(target,exp[1])])
    
    return end_with_link(linkage,intseq)

def compile_variable(exp,target,linkage):
    intseq = make_inst_sequence(['env']
                                ,[target]
                                ,['(assign {0} (op lookup_var) (const {1}) (reg env))'.format(target,exp[1])])
    return end_with_link(linkage,intseq)

##special forms-------------

def compile_assign(exp,target,linkage):
    var = exp[1][1]
    valcode = compiler.compile(exp[2],'val','next')
    intseq = make_inst_sequence(['env','val']
                                ,[target]
                                ,['(perform (op set_var) (const {0}) (reg val) (reg env))'.format(var)
                                  ,'(assign {0} (const ok))'.format(target)])
    resv = preserve(['env'],valcode,intseq)
    return end_with_link(linkage,resv)
    
def compile_definition(exp,target,linkage):
    var = exp[1][1]
    valcode = compiler.compile(exp[2],'val','next')
    intseq = make_inst_sequence(['env','val']
                                ,[target]
                                ,['(perform (op define_var) (const {0}) (reg val) (reg env))'.format(var)
                                  ,'(assign {0} (const ok))'.format(target)])
    resv = preserve(['env'],valcode,intseq)
    return end_with_link(linkage,resv)

def compile_ifstmt(exp,target,linkage):
    pred = exp[1]
    consq = exp[2]
    alt = exp[3]
    true_label= make_label('true_branch')
    false_label = make_label('false_branch')
    done_label =  make_label('if_done')
    if_linkage = ''
    if linkage =='next':
        if_linkage = done_label[1]
    else:
        if_linkage = linkage
   
    predcode = compiler.compile(pred,'val','next')
    consqcode = compiler.compile(consq,target,if_linkage)
    altcode = compiler.compile(alt,target,linkage)

    predjump = make_inst_sequence(['val']
                                  ,[]
                                  ,[ '(test (op isfalse) (reg val))'
                                    ,'(branch  {0})'.format(false_label)])


    second = parallel_seq( append_seq(make_inst_sequence([],[],[true_label]),consqcode)
                                   
                           ,append_seq(make_inst_sequence([],[],[false_label]),altcode))
                          
    wh = append_seq(predjump,second)
    wh2 = append_seq(wh, make_inst_sequence([]
                                            ,[]
                                            ,[done_label]))
    res = preserve(['env','continue'],predcode,wh2)
    return end_with_link(linkage,res)
    

def comp_seq(exp,target,linkage):
    if len(exp) == 1:
        seq = compiler.compile(exp[0],target,linkage)
        return seq
    else:
        cars= exp[0]
        crds= exp[1:]
        cardcode = compiler.compile(cars,target,'next')    #all result to target ?
        print(crds)
        crdcode = comp_seq(crds,target,linkage)
        return preserve(['env','continue'],cardcode,crdcode)

def compile_begin(exp,target,linkage):
    seq = exp[1:]
    return comp_seq(seq,target,linkage)
        
def compile_lambda(exp,target,linkage):
    print(exp)
    proc_entry = make_label('entry')
    after_lambda = make_label('after_lambda')
    lambda_linkage =''
    if linkage =='next':
        lambda_linkage = after_lambda[1]
    else:
        lambda_linkage = linkage

    inst = make_inst_sequence(['env']
                            ,[target]
                            ,['(assign {0} (op make_compiled_proc)  {1} (reg env))'.format(target,proc_entry)])
    proc_obj = end_with_link(lambda_linkage,inst)  # procedure oject is over here
    body = compile_labmda_body(exp,proc_entry)
    code_seq = tack_on_inst_seq(proc_obj,body)
    label_seq = make_inst_sequence([]
                                   ,[]
                                   ,[after_lambda])
    return append_seq(code_seq,label_seq)


def compile_labmda_body(exp,proc_entry):
    formals = exp[1]
    inst = make_inst_sequence(['env','proc','argl']
                            ,['env']
                            ,[ proc_entry
                              ,'assign env (op compile_proc_env) (reg proc))'
                              ,'assign env (op extend_env) (const {0}) (reg argl) (reg env)'.format(formals)])

    body_seq = compiler.compile(exp[2],'val','return')

    allcode = append_seq(inst,body_seq)
    return allcode

def compile_application(exp,target,linkage):
    op = exp[1]
    oprands = exp[2]
    opcode = compiler.compile(op,'proc','next')
    oprandcode = [] 
    for oprd in oprands:
        opc = compiler.compile(oprd,'val','next')
        oprandcode.append(opc)

    argseq = construct_arg(oprandcode)
    comp_proc_call = compile_proc_call(target,linkage)
    
    pcode = preserve(['proc','continue']
                        ,argseq
                        ,comp_proc_call)

    allcode = preserve(['env','continue']
                       ,opcode
                       ,pcode)
    return allcode


def construct_arg(oprands_code):
    if len(oprands_code) ==0:
        make_inst_sequence([],['argl'],['(assign argl (const ?))'])
    code_to_get_last_arg = append_seq(oprands_code[0],
                                      make_inst_sequence(['val'],['argl'],['(assign argl (op list) (reg val))']))
    return []


def  compile_proc_call():
    pass


def compile_cond(exp,target,linkage):
    print('compile_cond')

