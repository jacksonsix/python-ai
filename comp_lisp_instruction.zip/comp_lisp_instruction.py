#basic insturctions

#(test (op =) (reg n) (const 1))
#(branch (label base-case)

#(assign n (op -) (reg n) (const 1))

# (goto (label fact-loop))

 #extend with stack
# (save n)
# (restore n)

#command is list, first member is operation
#everythin inside a () is within a command  operation and oprands
#process with type.  test,branch ...
# process recursive,first , rest
#process into struct node.
 

comlist={'define','if','cond','self',
         'variable','lambda','begin',
         'set!','cons','car','cdr','quote'}

consts=set()

def make_nodes(str):
     word=''
     word_list=[]
     skip=False
     count =0
     for ch in str:
         if(ch ==' '):
             if(skip):
                 word += ch
                 continue
             else:
                 word_list.append(word)
                 word=''
         elif(ch =='('):
             if(count ==1):
                 skip=True
                 word += ch
             count += 1    
             
         elif(ch==')'):           
             if(count ==2):
                 skip=False
                 word += ch
             count -=1    

         else:
             word = word + ch
     word_list.append(word)        
     return word_list
            
def make_command(cmdstring):
    command=[]
    t = make_nodes(cmdstring)
    op = t[0]
    oprands = t[1:]
    if(op in comlist):
        command.append(op)
        for para in oprands:
            if(para.find('(') ==-1):
                command.append(['const',para])
            else:
                incom=make_command(para)
                command.append(['const',incom])
            
    else:
         command=notkeyword(t)
     
    return command

def notkeyword(t):
     print(t)
     op=t[0]
     oprands = t[1:]
     command=[]
     command.append('application')
     command.append(op)
     for para in oprands:
          if(para.find('(') ==-1):
               command.append(para)
          else:
               incom=make_command(para)
               command.append(incom)
     return command           

def normalize_const():
     pass


def statics_code(codes):
     insts=[]
     labels=dict()
     scanlabel(codes,insts,labels)
     gotoset=set()
     assignset=set()
     stackset=set()
     registers=set()
     libs=set()
     nodes=set()
     edges=set()
     
     for it in insts:
          evt = it[0]
          its =listtostr(it)
          
          if evt =='assign':
               assignset.add(its)
               i2= it[2]
               if i2[0] =='op':
                    libs.add(its)
          elif evt == 'goto':
               gotoset.add(its)
          elif evt =='save' or evt =='restore':
               stackset.add(its)
          elif evt =='perform':
               libs.add(its)
          elif evt == 'test':
               i1= it[1]
               if i1[0] == 'op':
                    libs.add(its)

     keys=[]
     for it in insts:
          keys.append(listtostr(it))
          
     for a in assignset:
          i = keys.index(a)
          stm= insts[i]
          registers.add(stm[1])
          to =stm[1]
          fr = stm[2]
          if fr[0] =='op':
               fr = fr[1]
               edges.add(fr+ '->'+to+','+fr+','+to+','+str(i))
     for g in gotoset:
          i= keys.index(g)
          stm = insts[i]

     for s in stackset:
          i=keys.index(s)
          stm = insts[i]
          registers.add(stm[1])
          if stm[0] =='save':
               edges.add(stm[1]+'->stack,'+stm[1]+',stack'+','+str(i))
          else:
               edges.add('stack->' + stm[1]+',stack,'+stm[1]+','+str(i))

     for l in libs:
          i = keys.index(l)
          stm = insts[i]
          if stm[0] == 'assign':
               op = stm[2:]
          elif stm[0] == 'test':
               op = stm[1:]
               
          opname = op[0][1]
          oprands =op[1:]
          for opd in oprands:
               if opd[0] == 'reg':
                    nodes.add('reg,'+opd[1])
                    edges.add(opd[1]+'->'+opname+','+opd[1]+','+opname+','+str(i))
          nodes.add('op,'+opname)

     for r in registers:     
          nodes.add('reg,'+r)



     result = dict()
     result['reg']= registers
     result['edges']= edges
     result['nodes']= nodes
     return result

def listtostr(lt):
     lstr=''

     if type(lt) is list:
          for i in lt:
               lstr += listtostr(i)
     elif lt is None:
	       lstr +=''
     else:
               lstr += str(lt)
     return lstr    

from graphviz import Digraph
def machine_view(codes):
     result = statics_code(codes)
     edges = result['edges']
     nodes = result['nodes']
     f = Digraph('reg_machine', filename='regm.gv')
     f.attr(rankdir='LR', size='8,5')
     f.attr('node', shape='circle')
     for n in nodes:
          ns = n.split(',')
          if ns[0] == 'reg':
               f.node(ns[1],ns[1],shape='egg')
          elif ns[0] =='op':
               f.node(ns[1],ns[1],shape='box')
          
     for ed in edges:
          eds = ed.split(',')
          f.edge(eds[1],eds[2],label=eds[3])

     f.view()

def log_static():
     f=open('C:/_dev/PythonTest/log.txt',"r")
     st=dict()
     
     for line in f:
          ls = line.split(':')
          nm = ls[2].strip()
          v= st.get(nm)
          if v is None:
               st[nm]=1
          else:
               st[nm] = v+1
               
     for d in st:
          print(d +': ' + str(st[d]))
          
