#code gen
import comp_lisp_instruction as asm
import compiler 

def make_inst_sequence(needs,modifies,stms):
    result=dict()
    result['needs']=needs
    result['modifies']=modifies
    result['stms']=stms
    return result

def make_empty_sequence():
    result=dict()
    result['needs']=[]
    result['modifies']=[]
    result['stms']=[]
    return result


#----------------------------------------
def preserve(regs,s1,s2):
    r1 = s1.get('needs')
    r2 = s1.get('modifies')
    r3 = s1.get('stms')

    r4 = s2.get('needs')
    r5 = s2.get('modifies')
    r6 = s2.get('stms')

    setn = set(r4)
    setm= set(r2)
    setn.intersection_update(setm)
    saves=[]
    restores=[]
    for s in regs:
        if s in setn:
            saves.append('(save {0})'.format(s))
            restores.append('(restore {0})'.format(s))
    

    r1.extend(r4)
    r2.extend(r5)
        
    r3.extend(saves)    
    r3.extend(r6)
    r3.extend(restores)    
    
    r = make_inst_sequence(r1,r2,r3)
    return r 

def compile_linkage(link):
    result=None
    if link =='return':
        result = make_inst_sequence(['continue']
                                        ,[]
                                        ,['(goto (reg continue))'])
    elif link =='next':
        result = make_empty_sequence()
    else:
        result = make_inst_sequence([]
                                        ,[]
                                        ,['(goto (label {0}))'.format(link)])
   
    return result    

def end_with_link(link,sequence):
    return preserve(['continue']
             ,sequence
             ,compile_linkage(link))
#----------------------------------------

def compile_self(exp,target,linkage):
    intseq = make_inst_sequence([]
                                ,[target]
                                ,['(assign {0} (const {1}))'.format(target,exp[1])])
    return end_with_link(linkage,intseq)
    
def compile_quote(exp,target,linkage):
    intseq = make_inst_sequence([]
                                ,[target]
                                ,['(assign {0} (const  {1}))'.format(target,exp[1])])
    
    return end_with_link(linkage,intseq)

def compile_variable(exp,target,linkage):
    intseq = make_inst_sequence(['env']
                                ,[target]
                                ,['(assign {0} (op lookup_var) (const {1}) (reg env))'.format(target,exp[1])])
    return end_with_link(linkage,intseq)

def compile_assign(exp,target,linkage):
    var = exp[1]

    valcode = compiler.compile(exp[2],'val','next')
    intseq = make_inst_sequence(['env','val']
                                ,[target]
                                ,['(perform (op set_var) (const {0}) (reg val) (reg env))'.format(var)
                                  ,'(assign {0} (const ok))'.format(target)])
    resv = preserve(['env'],valcode,intseq)
    return end_with_link(linkage,resv)
    
def compile_definition(exp,target,linkage):
    var = exp[1]
    valcode = compiler.compile(exp[2],'val','next')
    intseq = make_inst_sequence(['env','val']
                                ,[target]
                                ,['(perform (op define_var) (const {0}) (reg val) (reg env))'.format(var)
                                  ,'(assign {0} (const ok))'.format(target)])
    resv = preserve(['env'],valcode,intseq)
    return end_with_link(linkage,resv)

def compile_ifstmt(exp,target,linkage):
    print('compile_ifstmt')
def compile_lambda(exp,target,linkage):
    print('compile_lambda')
def compile_begin(exp,target,linkage):
    print('compile_begin')
def compile_cond(exp,target,linkage):
    print('compile_cond')
def compile_application(exp,target,linkage):
    print('compile_application')
