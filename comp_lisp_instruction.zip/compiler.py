#compiler
import comp_code_gen as gen

def getType(cmd):
    return cmd[0]

def append_sequence(s1,s2):
    s1.extend(s2)
    return s1



    
def compile(exp,target,linkage):
    t = getType(exp)
    gen_code_dict=dict()
    gen_code_dict['self'] = gen.compile_self
    gen_code_dict['quote'] = gen.compile_quote
    gen_code_dict['variable'] = gen.compile_variable
    gen_code_dict['set!'] = gen.compile_assign
    gen_code_dict['define'] = gen.compile_definition
    gen_code_dict['ifstmt'] = gen.compile_ifstmt
    gen_code_dict['lambda'] = gen.compile_lambda
    gen_code_dict['begin'] = gen.compile_begin
    gen_code_dict['cond'] = gen.compile_cond
    gen_code_dict['application'] = gen.compile_application

    cur_gen = gen_code_dict.get(t)

    if cur_gen is None:
        print(exp)
        raise Exception('no such expression')
    else:
        return cur_gen(exp,target,linkage)
