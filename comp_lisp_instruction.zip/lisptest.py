#lisptest

import compiler as comp

import comp_lisp_instruction as asm


def checkseq(s):
    r1 = s.get('needs')
    r2 = s.get('modifies')
    r3 = s.get('stms')

    print('needs: ')
    if r1 is not None:
        for i1 in r1:
            print(i1)
    print('modify: ')        
    if r2 is not None:
        for i1 in r2:
            print(i1)
    print('stmts: ')        
    if r3 is not None:
        for i1 in r3:
            print(i1)

def test1():
    compiler.compile(['self','3'],'','')



def test2():
    c ='(if a 1)'
    m = asm.make_nodes(c)
    for ea in m:
        print(ea)
    ac = asm.make_command(c)
    for a in ac:
        print(a)

def test_comp():
    cmd ='(self 4)'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','next')
    checkseq(s)

def test_comp1():
    cmd ='(self 4)'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_comp2():
    cmd ='(quote abc)'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','label3')
    checkseq(s)

def test_comp3():
    cmd ='(variable abc)'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)
    
def test_comp4():
    cmd ='(set! a (self 6))'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','lab1')
    checkseq(s)

def test_comp5():
    cmd ='(define a (self 6))'
    inst = asm.make_command(cmd)
    s = comp.compile(inst,'val','return')
    checkseq(s)

def test_comp6():
    cmd ='34'
    inst =  asm.make_command(cmd)
    for i in inst:
        print(i)

    
test_comp6()
