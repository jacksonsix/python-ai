
registers=dict()
stack=[]
libs=dict()
runprocs=[]
labels=dict()

def load_inst(procs):
    global runprocs
    runprocs = procs

def loadlabel(ls):
    global labels
    labels = ls
    
def check_inst():
    global runprocs
    return runprocs
      
count=0
def run():
    global runprocs
    global registers
    global count
    pc = registers['pc']
    print('step: '+ str(count) + ': ' + str(pc))
    count +=1
    if(pc < len(runprocs)):
        cur_inst = runprocs[pc]
        cur_inst[1]()
        run()
    else:
        print('over')

def get_reg(name):
    global registers
    r = registers.get(name)
    if(r is None):
        raise Exception('regiter not exists')
    else:
        return r

def set_reg(name,val):
    global registers
    r = registers.get(name)
    if(r is None):
        raise Exception('regiter not exists')
    else:
        registers[name]=val
        
def add_reg(name):
    global registers
    registers[name]= '*'

def add_libs(ulibs):
    global libs
    libs = ulibs


def print_snap():
    global registers
    global stack
    global runprocs
    global labels
    
    print('registers:')
    for r in registers:
        print('reg :' + r + ' = ' + str(registers[r]))
        
    print('stack:')    
    for s in stack:
        print(s)
        
    print('instructions:')
    for i in runprocs:
        print(i[0])
   
    print('labels:')
    for i in labels:
        print(i +': ' + str(labels[i])) 

def make_machine():
    global registers
    global stack
    registers['pc']= 0
    registers['flag'] = False

    def dispatch(msg):
        if(msg=='load'):
            return load_inst
        elif(msg == 'loadlabel'):
            return loadlabel
        elif(msg=='get_libs'):
            return libs
        elif(msg == 'run'):
            run()
        elif(msg =='get_reg'):
            return get_reg
        elif(msg =='set_reg'):
            return set_reg
        elif msg =='add_reg':
            return add_reg
        elif msg == 'add_libs':
            return add_libs
        elif msg == 'get_stack':
            return stack
        elif msg == 'print_snap':
            print_snap()
        else:
            raise Exception('machine not support command')
    return dispatch
