def vect_ref(vect,n):
    return vect[n]


def vect_set(vect,n,val):
    vect[n]= val

    
