import paho.mqtt.client as mqtt
import time

def on_connect(client,userdata,flags,rc):
    if rc == 0:
        print('client is connected')
        global connected
        connected = True
    else:
        print('client is not connected')

def on_message(client,userdata,message):
    print('Message recev: ' + str(message.payload.decode('utf-8')))
    print('4')


connected = False
Messagerec = False

broker_address='localhost'
port = 12551
user='user'
password = 'goodpass'

client  =  mqtt.Client("MQTT")
client.username_pw_set(user,password=password)
client.on_connect =  on_connect
client.on_message = on_message

client.connect(braoker_address,port=port)
client.loop_start()
client.subscribe('mqtt/secondecode')

while connected is False:
    time.sleep(0.2)

while Messagerec is False:
    time.sleep(0.2)

client.loop_stop()

###  cloudMQTT


