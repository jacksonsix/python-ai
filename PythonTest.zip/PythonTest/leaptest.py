#leap test
import pleapfrog as frog

def test1():
    s = frog.create(11,12,13,14)
    frog.display(s)
    #frog.dumpold()

def test2():
    s1 = frog.create('a','b','c')
    s2 = frog.create(9,6,3,6)
    frog.display(s1)
    frog.display(s2)
    frog.dumpold()

def test3():
    s1 = frog.create('a','b','c')
    s2 = frog.create(9,6,3,6)
    n1 = frog.compact_copy(s1)
    #frog.dumpold()
    frog.display(n1)
    
test3()
