
registers=dict()
stack=[]

libs=dict()
runprocs=[]
labels=dict()
breakpoints=[]

def load_inst(procs):
    global runprocs
    runprocs = procs

def loadlabel(ls):
    global labels
    labels = ls
    
def check_inst():
    global runprocs
    return runprocs

def print_r():
    global registers
    for v in registers:
        print(v +' is: ' + str(registers[v]))
      
count=0
logf=open('C:/_dev/PythonTest/log.txt',"w")

def run():
    global runprocs
    global registers
    global count
    while True:
        pc = registers['pc']
        logf.write('step: '+ str(count) + ': ' + str(pc)+'\n')
        count +=1

        if pc in breakpoints:
            while True:
                cmd = input("input command for debug: ")
                if cmd == 'c':
                    break
                elif cmd =='p':
                    print_r()
  
        if(pc < len(runprocs)):
            cur_inst = runprocs[pc]
            cur_inst[1]()
        else:
            break
        
    print('--------over---------')
    logf.close()
        

def get_reg(name):
    global registers
    r = registers.get(name)
    if(r is None):
        raise Exception('regiter not exists')
    else:
        return r

def set_reg(name,val):
    global registers
    r = registers.get(name)
    if(r is None):
        raise Exception('regiter not exists')
    else:
        registers[name]=val
        
def add_reg(name):
    global registers
    registers[name]= '*'

def add_libs(ulibs):
    global libs
    libs = ulibs

def add_brk(n):
    global breakpoints
    breakpoints.append(n)

def print_snap():
    global registers
    global stack
    global runprocs
    global labels
    
    print('registers:')
    for r in registers:
        print('reg :' + r + ' = ' + str(registers[r]))
        
    print('stack:')    
    for s in stack:
        print(s)
        
    print('instructions:')
    for i in runprocs:
        print(i[0])
   
    print('labels:')
    for i in labels:
        print(i +': ' + str(labels[i])) 

def make_machine():
    global registers
    global stack
    registers['pc']= 0
    registers['flag'] = False

    def dispatch(msg):
        if(msg=='load'):
            return load_inst
        elif(msg == 'loadlabel'):
            return loadlabel
        elif(msg=='get_libs'):
            return libs
        elif(msg == 'run'):
            run()
        elif(msg =='get_reg'):
            return get_reg
        elif(msg =='set_reg'):
            return set_reg
        elif msg =='add_reg':
            return add_reg
        elif msg == 'add_libs':
            return add_libs
        elif msg == 'get_stack':
            return stack
        elif msg == 'print_snap':
            print_snap()
        elif msg =='add_brk':
            return add_brk
        else:
            raise Exception('machine not support command')
    return dispatch
