import mstack
import mreg
import pinstrucstorage


registers=dict()
stack=[]
libs=dict()
instructions=[]
lables=dict()

def load_inst(codelist):
    pinstrucstorage.scanlabel(codelist,instructions,lables)

def check_inst():
    global instructions
    return instructions

def exe(cmd):
    print(cmd)

def run():
    global instructions
    global registers
    pc = registers['pc']
    pt = pc('get')
    cur_inst = instructions[pt]
    exe(cur_inst)
    if(pt < len(instructions)-1):
        pc('set')(pt+1)
        run()
    else:
        print('over')
        
def make_machine():
    global registers
    global stack
    registers['pc']= mreg.make_register()
    registers['flag'] = mreg.make_register()
    pc = registers['pc']
    flag = registers['flag']
    pc('set')(0)
    flag('set')(False)
    def dispatch(msg):
        if(msg=='load'):
            return load_inst
        elif(msg=='checkcode'):
            return check_inst
        elif(msg == 'run'):
            return run
    return dispatch
