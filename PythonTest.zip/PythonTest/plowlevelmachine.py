#low level machine

def make_machine():
    def test():
        print('test func')
        
    def dispatch(cmd):
        if(cmd=='test'):
            test()
    return dispatch




ans = make_machine()
ans('test')
    
    
