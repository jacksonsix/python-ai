#set operator x


def filldata(file):
    f=open(file,"r")
    thislist=[]
    for line in f:
        words=line.split(',')
        thistuple=(words[0], words[1])
        thislist.append(thistuple)
    f.close()    
    return thislist

def getcolumn(set1,index):
    col=set()
    for x in set1:
        col.add(x[index])
    return col

def getRow(set1,index,key):
    for row in set1:
        if row[index] == key:
            return row
    return None    

def fulljoin(set1,set2):
    finallist=[]
    for e1 in set1:
        list1=list(e1)
        for e2 in set2:
            list2=list(e2)
            finallist.append(tuple(list1+list2))
    return finallist        

#inner join
def filteron(fullset,index1,index2):
    finallist=[]
    for e1 in fullset:
        if e1[index1] == e1[index2]:
            finallist.append(e1)
    return finallist        


            
#left join
def leftfilteron(fullset,index1,index2):
    finallist=[]
    keys = getcolumn(fullset,index1)
    found=set()
    for e1 in fullset:
        if  e1[index1] == e1[index2]:
            found.add(e1[index1])
            finallist.append(e1)
    dif = keys.difference(found)
    print(keys)
    print(found)
    print(dif)
    for k in dif:
        ap = getRow(fullset,index1,k)
        l = list(ap)
        finallist.append(l[:index2])
    return finallist
#right join

    
    
t1=filldata("table1.txt")
t2 = filldata("table2.txt")

ff= fulljoin(t1,t2)
tt = leftfilteron(ff,0,2)
for line in tt:
    print(line)
    

print('keep right')

fr = fulljoin(t2,t1)
tr = leftfilteron(fr,0,2)
for line in tr:
    print(line)

    
