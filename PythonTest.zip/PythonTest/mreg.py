#machine

content='*'
def make_register():
    
    def setr(x):
        global content
        content=x
        
    def dispatch(msg):
        global content
        if(msg=='get'):
            return content
        elif(msg=='set'):
            return setr
        else:
            raise Exception('register command error')
    return dispatch







