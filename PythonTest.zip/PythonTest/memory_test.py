import memory as mem


def test1():
    
    tp1=mem.set_type_data('int',6)
    tp2=mem.set_type_data('float',9.3)
    print(mem.get_type_data(tp1))
    print(mem.get_type_data(tp2))
    mem.dump()

def test2():
    tped = mem.set_type_data('int',8)
    print(mem.get_type(tped))
    mem.dump()

def test3():
    p = mem.set_pair_data(1,2)
    d = mem.get_pair_data(p)
    print(d)
    mem.dump()

def test4():
    p1 = mem.set_pair_data(1,2)
    p2 = mem.set_pair_data(4,p1)
    f = mem.get_pair_data(p2)
    print(f)
    mem.dump()
    
def test4():
    p1 = mem.set_pair_data(1,2)
    p2 = mem.set_pair_data(3,4)
    p3 = mem.set_pair_data(p2,p1)
    f = mem.get_pair_data(p3)
    print(f)
    mem.dump()

def test5():
    p1 = mem.cons(1,2)
    p2 = mem.cons(4,p1)
    f = mem.get_pair_data(p2)
    print(f)
    d = mem.car(p2)
    print(d)
    e = mem.cdr(p2)
    print(e)
    mem.dump()

def test6():
    p1 = mem.cons(1,2)
    p2 = mem.cons(4,p1)
    f = mem.get_pair_data(p2)
    print(f)
    mem.set_car(p1,9)
    print(mem.get_pair_data(p1))

    mem.dump()

def test7():
    mem.save(8)
    mem.save('we')
    f = mem.restore()
    w = mem.restore()
    print(f)
    print(w)

def test8():
    p1 = mem.cons(3,4)
    p2 = mem.cons(1,2)
    mem.setcdr(p1,p2)
    print(mem.get_pair_data(p1))

def test9():
    w = mem.clist(1,2,3,4)
    print(mem.get_pair_data(w))
    mem.dump()

def test10():
    s = mem.cons(1,2)
    y = mem.clist(s,s)
    print(mem.get_pair_data(y))
    mem.dump()
    
def test11():
    mem.move()
    mem.dump()
    mem.dump2()
    
test11()
