mypath='C:/Users/jliang/DEV_LAB/Ordering3/github/back-office-service/src/main/java/com/elementfleet/ordering3/stock/util'

from os import walk

fs = []
for (dirpath, dirnames, filenames) in walk(mypath):
    fs.extend(filenames)
    print(filenames)
    break

newlines=[]
for file in fs:
    
  f=open(mypath+'/'+file,"r")
  for line in f:
      if(line.find('package') >= 0 ):
          print(line)
          line = 'package com.elementfleet.ordering3.stock.util;\n'
      newlines.append(line)    
      
  f.close()


  fw=open(mypath+'/'+file,"w")
  fw.writelines(newlines)
  fw.close()
  newlines=[]
  
  
  

