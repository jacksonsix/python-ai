#m execute 

def exe(cmd):
    
