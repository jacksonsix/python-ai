#frog with bag

#[typdata,nextpointer]
# ['typed',start,len]

old=[]
new=[]

ofree = 0
nfree = 0

otypfree = 0
ntypfree = 0

MEM_SIZE = 200

for x in range(MEM_SIZE):
    old.append('*')
    new.append('*')


def create_node(c):
    global ofree
    global old
    node =[]
    node.append(c)
    node.append(None)
    old[ofree] = node
    ofree += 2
    return ofree -2

def create_typedata(td):
    global otypfree
    global MEM_SIZE
    lg = 0
    try:
        lg = len(td)
    except:
        lg = 0
 
    node = ['typed',otypfree]
    node.append(lg)
    if lg > 0:
        for i in range(lg):
            old[MEM_SIZE - otypfree - i -1] = td[i]
        otypfree += lg    
    else:
        old[MEM_SIZE - otypfree -1] = td
        otypfree += 1
               
    return node

def connect(prev,cur):
    global old
    p = old[prev]
    p[1] = cur
    
def create(*arg):
    global ofree
    i = 0
    nxt = None
    head = ofree
    prev =0
    while i < len(arg):
        c = arg[i]
        tdata = create_typedata(c)
        addr = create_node(tdata)
        if i ==0:
            head = addr
        else:    
            connect(prev,addr)
        prev = addr
        i += 1
    return head

def display(index):
    n = old[index]
    inter =  n[0]

    if inter[2] == 0:
        print(old[MEM_SIZE - inter[1] -1])
    else:
        s=''
        for i in range(inter[2]):
            s += old[MEM_SIZE - inter[1] - i -1]
        print(s)    
    if n[1] is not None:
        display(n[1])
    
def dumpold():
    global old
    l = len(old)
    for x in range(l):
        print(old[x])
        
def dumpnew():
    global new
    l = len(new)
    for x in range(l):
        print(new[x])    
        

def compact_copy(start):
    global old
    global new
    global nfree
    global ofree
    global ntypfree
    i = start
    head = nfree
    while i is not None:
        n = old[i]
 #move typed data first
        tp = n[0]
        oldtp = tp[1]
        oldtplen = tp[2]
        newhead = ntypfree
        tp[1] = newhead
        n[0] = tp        
        if oldtplen == 0:
            new[MEM_SIZE - ntypfree -1] = old[MEM_SIZE - oldtp -1]
            ntypfree += 1
        else:
            for ts in range(oldtplen):
                new[MEM_SIZE - ntypfree -1] = old[MEM_SIZE - oldtp - ts -1]
                ntypfree += 1   
#move node        
        i = n[1]
        if n[1] is not None:
            n[1] = nfree + 1
        new[nfree] = n
        nfree += 1

    t = old
    old = new
    new = t
    nfree = 0
    ofree = 0
    ntypfree = 0
    otypfree = 0
    return head

    
