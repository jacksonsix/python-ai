f=open("txt.txt")

f2 = open("smal.txt","w")

for line in f:
    if(line.find('/') == -1 ):
        if(len(line.strip()) > 0):
          f2.write(line )
    else:
        if(line.find('driverGroupService') >-1):
            f2.write(line )
   
f.close()
f2.close()


