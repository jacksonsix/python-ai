#tree with bag

#[typdata,nextpointer]
# ['typed',start,len]

old=[]
new=[]

ofree = 0
nfree = 0

otypfree = 0
ntypfree = 0

MEM_SIZE = 300
PAIR_SPLIT = 100

for x in range(MEM_SIZE):
    old.append('*')
    new.append('*')

def set_vect(mem,offset,val):
    mem[offset] = val
    
def get_vect(mem,offset):
    return mem[offset]

def create_pair():
    global ofree
    global old
    global PAIR_SPLIT
    node =['pair']
    node.append(ofree)
    set_vect(old,ofree,None)
    set_vect(old,ofree + PAIR_SPLIT,None)
    ofree += 2
    return node

def set_car(pair,pt):
    global old
    index = pair[1]
    set_vect(old,index,pt)

def set_cdr(pair,pt):
    global old
    global PAIR_SPLIT
    index = pair[1]
    set_vect(old,index + PAIR_SPLIT,pt)

def get_car(pair):
    global old
    index = pair[1]
    return get_vect(old,index)

def get_cdr(pair):
    global old
    global PAIR_SPLIT
    index = pair[1]
    return get_vect(old, index + PAIR_SPLIT)

def create_typedata(td):
    global otypfree
    global MEM_SIZE
    lg = 0
    try:
        lg = len(td)
    except:
        lg = 0
 
    node = ['typed',otypfree]
    node.append(lg)
    if lg > 0:
        for i in range(lg):
            old[MEM_SIZE - otypfree - i -1] = td[i]
        otypfree += lg    
    else:
        old[MEM_SIZE - otypfree -1] = td
        otypfree += 1
               
    return node

def get_type(data):
    ty =''
    if data is None:
        return None
    
    try:
        ty = data[0]
    except:
        ty = 'userdata'
    return ty    

def upward(dt):
    ty = get_type(dt)
    paird = None
    if ty =='typed':
        paird = create_pair()
        set_car(paird,dt)
    elif ty =='userdata':
        memd = create_typedata(dt)
        paird = create_pair()
        set_car(paird,memd)
    elif ty =='pair':
        paird = d1
    else:
        pass
        #raise Exception('no such data type,cons')
    return paird

def cons(d1,d2):
    p1 = upward(d1)
    p2 = upward(d2)
    pair = create_pair()
    set_car(pair,p1)
    set_cdr(pair,p2)
    return pair
    

def display(pr):
    ty = get_type(pr)
    show_word ='('
    if ty =='pair':
        index = pr[1]
        car = get_car(pr)
        s1 = display(car)
        cdr = get_cdr(pr)
        s2 = display(cdr)
        return '(' + str(s1) +',' + str(s2) +')'
    elif ty =='typed':
        inter =  pr
        if inter[2] == 0:
            return (old[MEM_SIZE - inter[1] -1])
        else:
            s=''
            for i in range(inter[2]):
                s += old[MEM_SIZE - inter[1] - i -1]
            return s
    else:
        return 'None'
    
    
def dumpold():
    global old
    l = len(old)
    for x in range(l):
        print(old[x])
        
def dumpnew():
    global new
    l = len(new)
    for x in range(l):
        print(new[x])    
        

def compact_copy(start):
    global old
    global new
    global nfree
    global ofree
    global ntypfree
    i = start
    head = nfree
    while i is not None:
        n = old[i]
 #move typed data first
        tp = n[0]
        oldtp = tp[1]
        oldtplen = tp[2]
        newhead = ntypfree
        tp[1] = newhead
        n[0] = tp        
        if oldtplen == 0:
            new[MEM_SIZE - ntypfree -1] = old[MEM_SIZE - oldtp -1]
            ntypfree += 1
        else:
            for ts in range(oldtplen):
                new[MEM_SIZE - ntypfree -1] = old[MEM_SIZE - oldtp - ts -1]
                ntypfree += 1   
#move node        
        i = n[1]
        if n[1] is not None:
            n[1] = nfree + 1
        new[nfree] = n
        nfree += 1

    t = old
    old = new
    new = t
    nfree = 0
    ofree = 0
    ntypfree = 0
    otypfree = 0
    return head

    
