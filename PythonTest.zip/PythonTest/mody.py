f=open("c:/_dev/t1.txt")

for line in f:
    print(line)
    
    