content=[]
def make_stack():

    def dispatch(msg):
        global content
        if(msg=='push'):
            return lambda x: content.append(x)
        elif(msg=='pop'):
            return content.pop()
        else:
            raise Exception('stack command error')

    return dispatch
