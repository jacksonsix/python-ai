# memory, array of elements
# vector model
# (vector-ref vect n) read
# (vector-set! vect n value) write


memory = []  # 4k in char size
the_cars = 0  # 0-511
the_cdrs = 512  # 512 - 1023
the_primary = 4095  # backward from 4095
the_stack = 1024   #size 256
stack_top =0
free = 0
prim_free = 0

i = 0
while(i < 4096):
    memory.append('*')
    i += 1

### memory recycle half
memory_new = []  # 4k in char size
the_cars_new = 0  # 0-511
the_cdrs_new = 512  # 512 - 1023
the_primary_new = 4095  # backward from 4095
the_stack_new = 1024   #size 256
stack_top_new =0
free_new = 0
prim_free_new = 0

i = 0
while(i < 4096):
    memory_new.append('*')
    i += 1

    

def getm(i):
    global memory
    return memory[i]


def setm(i, val):
    global memory
    memory[i] = val


def set_car(i, val):
    setm(i + the_cars, val)


def set_cdr(i, val):
    setm(i + the_cdrs, val)


def get_car(i):
    return getm(i + the_cars)


def get_cdr(i):
    return getm(i + the_cdrs)


def set_prim(i, val):
    setm(the_primary - i, val)


def get_prim(i):
    return getm(the_primary - i)



def save(val):
    global the_stack
    global stack_top
    setm(the_stack+stack_top,val)
    stack_top += 1
    if stack_top == 256:
        raise Exception('stack overflow')

def restore():
    global the_stack
    global stack_top    
    c = getm(the_stack+stack_top-1)
    stack_top -= 1
    return c
    
# typed pointer here
# typed pointer  ['typedp','num',val]
# ['typedp','string',p_loc]

def get_type(v):
    if not isinstance(v, list):
        return 'error'
    elif v[0] != 'typedp':
        if v[0] == 'pair':
            return v[0]
        else:
            return 'error'
    else:
        return v[1]


def set_type_data(t, val):
    global prim_free
    c = ['typedp']
    c.append(t)
    c.append(prim_free)
    c.append(1)
    set_prim(prim_free, val)
    prim_free += 1
    return c


def get_type_data(tp):
    index = tp[2]
    c = get_prim(index)
    return c

def set_pair_data(d1,d2):
    global free
    c=['pair']
    c.append(free)
    typ1 = get_type(d1)
    typ2 = get_type(d2)
    if typ1 =='error':   #data not stored yet
        t1 = set_type_data('int',d1)
        set_car(free,t1)
    else:
        set_car(free,d1)
#### cdr link to next
    if typ2 =='error':
        t2 = set_type_data('int',d2)
        set_cdr(free,t2)
    else:
        set_cdr(free,d2)
        
    free += 1
    return c


def create_pair_data(d1):
    global free
    c=['pair']
    c.append(free)
    typ1 = get_type(d1)

    if typ1 =='error':   #data not stored yet
        t1 = set_type_data('int',d1)
        set_car(free,t1)
    else:
        set_car(free,d1)
    set_cdr(free,None)
    free += 1
    #if free > 1024:  garbage collect
        
    return c

def connect(d1,d2):
    pt = d1[1]
    set_cdr(pt,d2)
    
def get_pair_data(pp):
    t = get_type(pp)
    data=[]
    pfree = pp[1]
    carp = get_car(pfree)
    if get_type(carp) =='error':
        data.append(carp)
    elif get_type(carp) =='pair':
        
        data.append(get_pair_data(carp))
    else:
        data.append(get_type_data(carp))
        
    cdrp = get_cdr(pfree)
    if get_type(cdrp) =='error':
        data.append(cdrp)
    elif get_type(cdrp) =='pair':
        
        data.append(get_pair_data(cdrp))
    else:
        data.append(get_type_data(cdrp))
    return data
    


# finally cons,car,cdr
def cons(d1,d2):
    first = create_pair_data(d1)
    t = get_type(d2)
    if t == 'pair':
        second = d2
    else:
        second = create_pair_data(d2)
    connect(first,second)
    return first
    

def car(pp):
    if get_type(pp) =='pair':
        pt = pp[1]
        return get_car(pt)
    else:
        raise Exception('cannot car this ')

def cdr(pp):
    if get_type(pp) =='pair':
        pt = pp[1]
        return get_cdr(pt)   
    else:
        raise Exception('cannot cdr this ')
    
def setcar(pp,d):
    carp = pp[1]
    #check d type here,if d is already stored 
    typ1 = get_type(d)
    if typ1 =='error':   #data not stored yet
        t1 = set_type_data('int',d)
        set_car(carp,t1)
    else:
        set_car(carp,d)


def setcdr(pp,d):
    cdrp = pp[1]
    #check d type here,if d is already stored 
    typ1 = get_type(d)
    if typ1 =='error':   #data not stored yet
        t1 = set_type_data('int',d)
        set_cdr(cdrp,t1)
    else:
        set_cdr(cdrp,d)


def clist(*member):
    i =len(member)
    result = cons(member[i-2],member[i-1])
    i -= 1
    while i > 1:
        result = cons(member[i-2],result)
        i -= 1
    return result    
        
    
    
def dump():
    global memory
    f = open('C:/_dev/PythonTest/dump.txt', 'w')
    for c in memory:
        f.write(str(c)+'\n')
    f.close()

    
def dump2():
    global memory_new
    f = open('C:/_dev/PythonTest/dump2.txt', 'w')
    for c in memory_new:
        f.write(str(c)+'\n')
    f.close()
########### garbage recyle

    


mroot =0  ##old memory
mscan =0
mfree =0  ##new memory    
def move():


    def getm_new(i):
        global memory_new
        return memory_new[i]
    
    def setm_new(i,val):
        global memory_new
        memory_new[i] =val

    def set_type_data_new(t, val):
        global prim_free_new
        c = ['typedp']
        c.append(t)
        c.append(prim_free_new)
        c.append(1)
        setm_new(the_primary_new - prim_free_new, val)
        prim_free_new += 1
        return c

    def get_type_data_new(tp):
        index = tp[2]
        c = get_prim(index)
        return c

    def copy_prim(tydata):
        print(tydata)
        index = tydata[2]
        data = get_type_data(index)
# check if already moved        
        if(data[0] =='@'):
            n = data[1:]
            return int(n)
        else:
            cp = set_type_data_new('int',data)
#put flag here to indicate move
            set_type_data(index,'@'+str(cp[2]))
            return cp[2]

    def copy_pair(ch1,ch2):
        global mfree
        setm_new(the_cars_new + mfree,ch1)
        setm_new(the_cdrs_new + mfree,ch2)
        mfree += 1
        return mfree -1

    def mv(pt,wh,parent_new):
        global the_cars
        global the_cdrs 
        ch1 = get_car(pt)
        if ch1 =='@':
#already copied
            new_loc = get_cdr(pt)
            c = ['pair',new_loc]
            if wh =='car':              
                set_car(parent_new,c)
            else:
                set_cdr(parent_new,c)
                
        else:
            ch2 = get_cdr(pt) 
            p = copy_pair(ch1,ch2)
# set @ flag
            set_car(pt,'@')
            set_cdr(pt,p)            
            
# pair or prim?
            tp1 = get_type(ch1)
            if tp1 =='pair':                
                mv(ch1[1],'car',p)
            else:
                newloc = copy_prim(ch1)

            tp2 = get_type(ch2)
            if tp2 =='pair':
                mv(ch2[1],'car',p)
            else:
                copy_prim(ch2)
 


    mv(0,'car',0)
        
    
    
    

