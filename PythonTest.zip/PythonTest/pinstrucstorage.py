#instruction storage
import minstructions


def scanlabel(codelist,cmds,labels):
    i=0
    for line in codelist:
        cmd = minstructions.make_command(line)
        if(cmd[0] == 'label'):
            lbl = cmd[1]
            labels[lbl] = i
        else:
            cmds.append(cmd)
        i += 1    
    
