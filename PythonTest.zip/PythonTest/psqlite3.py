#sqlite3
import sqlite3
conn = sqlite3.connect("C:\\_dev\\sqlite\\test.db")
c = conn.cursor()
t=('')
c.execute('select * from ClassSet')
print(c.fetchone())
conn.commit()
conn.close()



# serialize the relation objec into sql statement

# entity -> relation

# name, [field,domain]+   pk, fk

class EntityRelation:
    def __init__(self,name,fields,pk,fk):
        self.name=name
        self.fields=fields
        self.pk=pk
        self.fk=fk

    def toStatement(self):
        fs=''
        for f in self.fields:
            fs = fs + f
        s= 'create table ' + self.name + ' (' + fs + ')'
        return s
        
    
t1= EntityRelation('table1',['col1 char(10)'],'','')
s=t1.toStatement()
print(s)
