import memory_v2 as v


s = v.vect_ref([0,1],1)
print(s)
print('ddff')

