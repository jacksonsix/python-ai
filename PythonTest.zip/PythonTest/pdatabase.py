import sqlite3
f=open('C:/Users/jliang/DEV_LAB/ordering_eclipse/zoomytest/src/fsm/t1',"r")

db_file = r"C:\_dev\sqlite\test.db"
conn = sqlite3.connect(db_file)
c = conn.cursor()
c.execute('''CREATE TABLE projectEdges
             (path text,fromNode text, toNode text)''')

for line in f:
    #print(line)
    line = line.strip('\n')
    ls = line.split(',')
    name=ls[0]
    fromn=ls[1]
    ton=ls[2].strip('\n')
    sql="INSERT INTO projectEdges VALUES ('"+name+ "','" +fromn+"','" +ton +"')"
    #print(sql)
    c.execute(sql)
    conn.commit()
    
for row in c.execute('SELECT * FROM projectEdges'):
    print(row)
conn.close() 

# create a database connection
#conn = sqlite3.connect(db_file)
#c = conn.cursor()
# Create table
#c.execute('''CREATE TABLE relations
#             (fromNode text, toNode text, className text)''')
# Insert a row of data
#c.execute("INSERT INTO stocks VALUES ('2006-01-06','BUY','RHAT',104,35.14)")
# Save (commit) the changes
#conn.commit()

#for row in c.execute('SELECT * FROM relations ORDER BY className'):
#        print(row)


# We can also close the connection if we are done with it.
# Just be sure any changes have been committed or they will be lost.
#conn.close()  
