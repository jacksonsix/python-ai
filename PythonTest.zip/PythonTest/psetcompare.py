f=open('C:/_dev/PythonTest/todel.txt',"r")
myset = set()
myset2 = set()
for line in f:
    myset.add(line.strip('\n'))


#print(myset)

f2=open('C:/_dev/PythonTest/3.txt',"r")

for line in f2:
    myset2.add(line.strip('\n'))

    
#s12 = myset - myset2

s21 = myset - myset2

print(myset2.issubset(myset))

#for w in s21:
#    print(w)




