

str ='(assign n (op -) (reg n) (const 1))'

l ='(label leaf)'

dd=[]
dd.append(str)
dd.append(str)
dd.append(l)
dd.append(str)


import machine


cmds=[]
lables=dict()


m = machine.make_machine()


m('load')(dd)

ch = m('checkcode')()

m('run')()

