
import machine_extended as bigm
import mlibs 

def testreg(): 
    dd=[]
    str ='(assign n (op rem) (reg n) (const 3))'
    dd.append(str)
    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',8)
    m('print_snap')
    m('run')
    m('print_snap')

def testassign():   
    dd=[]
    str ='(assign n (op rem) (reg n) (const 4))'
    dd.append(str)
    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',7)
    m('print_snap')
    m('run')
    m('print_snap')

def testtest():
    dd=[]
    str ='(test (op =) (reg n) (const 7))'
    dd.append(str)
    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',7)
    m('print_snap')
    m('run')
    m('print_snap')    

def testgoto():
    dd=[]   
    str ='(goto (label leaf))'   
    lb ='(label leaf)'
    nex = '(assign n (op rem) (reg n) (const 4))'
    dd.append(str)
    dd.append(lb)
    dd.append(nex)

    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',7)
    m('print_snap')
    m('run')
    m('print_snap')

def testbranch():
    dd=[]   
    str ='(test (op =) (reg n) (const 7))'
    brh='(branch (label leaf))'
    nex = '(assign n (op rem) (reg n) (const 4))'
    lb ='(label leaf)'
    
    dd.append(str)
    dd.append(brh)
    dd.append(nex)
    dd.append(lb)

    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',6)
    m('print_snap')
    m('run')
    m('print_snap')    

def testperf():
    dd=[]   
    str ='(perform (op +) (const 7) (const 5))' 
    dd.append(str)
    regs=['a','b','n']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,dd)
    m('setreg')('n',6)
    m('print_snap')
    m('run')
    m('print_snap')

    
  
def test_code():
    f=open('C:/_dev/PythonTest/code.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())
        print(line)
    regs=['a','b','t']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,codes)
    m('setreg')('a',6)
    m('setreg')('b',9)
    m('print_snap')
    m('run')
    m('print_snap')
    
def test_code1():
    f=open('C:/_dev/PythonTest/code1.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())

    regs=['n','continue','val']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,codes)
    m('setreg')('n',4)

    m('print_snap')
    m('run')
    m('print_snap')

def test_code2():
    f=open('C:/_dev/PythonTest/code2.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())

    regs=['n','continue','val']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,codes)
    m('setreg')('n',8)

    m('print_snap')
    m('run')
    m('print_snap')    

import minstructions as asm

def test_code2_statics():
    f=open('C:/_dev/PythonTest/code2.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())
    
    result = asm.statics_code(codes)
    regs = result['reg']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,codes)
    m('setreg')('n',19)

    m('print_snap')
    m('run')
    m('print_snap')
    asm.log_static()
    
def test_code2_statics2():
    f=open('C:/_dev/PythonTest/code2.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())
    
    asm.machine_view(codes)
   
def test_debug():
    f=open('C:/_dev/PythonTest/code2.txt',"r")
    codes=[]
    for line in f:
        codes.append(line.strip())
        
    result = asm.statics_code(codes)
    regs = result['reg']
    libs = mlibs.load_libs()   
    m = bigm.make_extend(regs,libs,codes)
    m('setreg')('n',3)

    m('print_snap')
    m('set_brk')(3)
    m('run')
    m('print_snap')
    asm.log_static()

    
test_debug()

    
