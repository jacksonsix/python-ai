f=open('C:/Users/jliang/DEV_LAB/Ordering3/github/parent/aggregate_pom.xml',"r")
myset = set() 
my1=set()
my2=set()

for line in f:
    if(line.find('module') > -1):
        myset.add(line.strip())



for t in myset:
   
    start = t.find("/")
    end = t.find("</")
    l=t[start+1:end]
    print(l)
    my1.add(l)

g=open('C:/Users/jliang/DEV_LAB/Ordering3/github/pull.bat',"r")

for line in g:
    if(line.find('cd')> -1  and len(line)>6):
        st= line.find('cd')
        my2.add(line[st+3:].strip())


for m in my2:
    #print(m)
    f=2

common = my1.intersection(my2)

n = my1.difference(my2)
z= my2.difference(my1)
print(z)

    
