f=open("cars.csv")

f2 = open("newcars.csv","w")

for line in f:
    #print(line)
    words = line.split()
    nl=""
    for word in words:
        nl = nl + word + ','
    nl=nl[:-1]
    f2.write(nl +'\n')
    print(nl)
f.close()
f2.close()


