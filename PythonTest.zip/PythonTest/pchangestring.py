f=open('C:/_dev/PythonTest/1.txt',"r")
myset = set() 

def getter():  
    for line in f:
        fs = line.split(' ')
        str=fs[0]
       
        if(len(fs) >1): 
            str += fs[1].title()
           
        if(len(fs) >2):
            str += fs[2].title()
            
        str = str.strip()
        name = str[0].upper() + str[1:]
        print('public String get'+name+'(' +') {')    
        print('  return '+str+';')

        print('}')

  


