import pandas
from sklearn import linear_model

df = pandas.read_csv("newcars.csv")


x = df[['Weight', 'Volume']]
y = df['CO2']

regr = linear_model.LinearRegression()
regr.fit(x, y)

#predict the CO2 emission of a car where the weight is 2300g, and the volume is 1300ccm:
predictedCO2 = regr.predict([[2300, 1300]])

print(predictedCO2)

print(regr.coef_)


import matplotlib.pyplot as plt

print(len(x))
print(len(y))
for w in y:
    print(w)
#plt.scatter(x, y)
#plt.show()
