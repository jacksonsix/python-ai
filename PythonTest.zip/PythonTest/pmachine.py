data_paths={}  #dictionary for name/value pair
sequence_code=[]

def rem(a,b):
    return a % b

data_paths['a']= 6
data_paths['b'] =8
data_paths['t'] =-1

data_paths['rem'] = rem



sequence_code.append('test-b')
sequence_code.append('(test =)')


#machine prims
def eq(d1,d2):
    return d1 == d2


def test(op,d1,d2):
    data_paths['test_result'] = op(d1,d2)

def branch(label):
    if(data_paths['test_result'] == false):
        return 'continue'
    c = sequence_code.find(label)
    if(c == -1):
        print('cannot find '+label)
    return c+1

def assign(r1,r2,r3=None,r4=None):
    if(r3 is None):
        data_paths[r1] = data_paths[r2]
    else:
        data_paths[r1] = data_paths[r2](data_paths[r3],data_paths[r4])

def goto(label):
    c = sequence_code.find(label)
    if(c == -1):
        print('cannot find '+label)
    return c+1    
    
data_paths['='] = eq
data_paths['test'] = test
data_paths['assign']= assign

def getop(line):
    s=line[1:]
    i=s.find(' ')
    if(i==-1):
        return 'label'
    else:
        return s[:i]

def test_b(line):
    print('test_b')
    
def branch_b(line):
    print('branch_b')

def assign_b(line):
    print('assign_b')

def goto_b(line):
    print('goto_b')

def label_b(line):
    print('label_b')
    
branches={'test':test_b,
          'branch':branch_b,
          'assign':assign_b,
          'goto':goto_b,
          'label':label_b
          }

for code in sequence_code:
    print(code)
    op = getop(code)
    branches[op](code)

    


