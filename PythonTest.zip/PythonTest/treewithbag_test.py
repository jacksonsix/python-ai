import treewithbag as tree

def test1():
    s = tree.cons(11,12)
    print(tree.display(s))
    tree.dumpold()

def test2():
    s1 = frog.create('ab','banana','c')
    s2 = frog.create(9,6,3,6)
    frog.display(s1)
    frog.display(s2)
    frog.dumpold()

def test3():
    s1 = frog.create('abbnd','xb','c')
    s2 = frog.create(9,6,3,6)
    h1 = frog.compact_copy(s1)
    
    frog.display(h1)
    frog.dumpold()
test1()
