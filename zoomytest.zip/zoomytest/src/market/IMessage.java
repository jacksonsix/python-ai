package market;

public interface IMessage {
	String getName();
	String getValue();
}
