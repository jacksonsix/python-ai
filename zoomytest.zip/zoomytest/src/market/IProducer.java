package market;

public interface IProducer {
	void produce();
}
