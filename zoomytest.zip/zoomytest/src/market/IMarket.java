package market;

public interface IMarket {
	IContext getContext();
}
