package market;

public interface IConsumer {
	
	void consume();
}
