package market;

public class Market {
	
	MessageContext env ;
	
	
	
	public static void main(String[] args) throws InterruptedException {
		
		//MessageContext stag1 = new MessageContext();
		
		//stag1.clearTask();
		
		
		FileSortContext stag2 = new FileSortContext();
		stag2.clearTask();
		
	}

}
