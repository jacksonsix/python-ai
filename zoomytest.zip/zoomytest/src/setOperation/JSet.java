package setOperation;

public class JSet {
	
	public JSet() {}
	
	public JSet and(JSet another) {
		return null;
	}
	
	public JSet or(JSet another) {
		return null;
	}
	
	
	

}
