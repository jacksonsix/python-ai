package jmsMQ;

public class LocalServer {
	
	public static void main(String[] args) {
		
	}

}
