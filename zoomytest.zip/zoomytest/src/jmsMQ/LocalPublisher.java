package jmsMQ;

public class LocalPublisher {

}
