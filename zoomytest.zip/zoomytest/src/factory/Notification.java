package factory;


/*
 *  In short, we are trying to achieve Pseudo polymorphism by letting the subclass to decide what to create
 *  This design pattern has been widely used in JDK
 * */
public interface Notification { 
    void notifyUser(); 
} 
