package singlepattern;

//Double Checked Locking based Java implementation of 
//SingletonBest design pattern 

/*
 * If you notice carefully once an object is created synchronization is no longer useful 
 * because now obj will not be null and any sequence of operations will lead to consistent results.
 *So we will only acquire lock on the getInstance() once, when the obj is null. 
 *This way we only synchronize the first way through, just what we want.
 * 
 * 
 * */
class SingletonBest {
	private volatile static SingletonBest obj;

	private SingletonBest() {
	}

	public static SingletonBest getInstance() {
		if (obj == null) {
			// To make thread safe
			synchronized (SingletonBest.class) {
				// check again as multiple threads
				// can reach above step
				if (obj == null)
					obj = new SingletonBest();
			}
		}
		return obj;
	}
}