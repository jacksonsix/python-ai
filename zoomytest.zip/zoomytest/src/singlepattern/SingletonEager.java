package singlepattern;

// thread safe, happen when jvm start 
//Static initializer based Java implementation of 
//SingletonEager design pattern 
/*Here we have created instance of singleton in static initializer. 
 * JVM executes static initializer when the class is loaded and hence this is guaranteed to be thread safe. 
 * 
 * */
class SingletonEager 
{ 
	 private static SingletonEager obj = new SingletonEager(); 
	
	 private SingletonEager() {} 
	
	 public static SingletonEager getInstance() 
	 { 
	     return obj; 
	 } 
} 