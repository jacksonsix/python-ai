package tools;

public class ExceptionWraper {

}
