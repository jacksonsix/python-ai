package other;

import java.util.UUID;

public class UUtest {
	public static void main(String[] args) {
		
		String uuid = UUID.randomUUID().toString();
		System.out.println(uuid);
	}

}
