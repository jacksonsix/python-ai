package abstractFactory;

public enum CarType 
{ 
    MICRO, MINI, LUXURY 
} 
