package abstractFactory;

public enum Location 
{ 
	  DEFAULT, USA, INDIA 
} 