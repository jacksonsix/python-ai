package graphattrib;

public interface IEvent {
	
	String getName();
	String getValue();

}
