package graphattrib;

public interface IListener {
	public void process(IEvent evt);
}
