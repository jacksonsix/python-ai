# load libs

libs=dict()
   

def minus(p1,p2):
    return p1-p2
def plus(p1,p2):
    return p1+p2
def remainder(p1,p2):
    return p1 % p2

def less(p1,p2):
    return p1 < p2

def morethan(p1,p2):
    return p1 > p2

def equ(p1,p2):
    return p1 == p2

def load_libs():
    global libs
    libs['-']=minus
    libs['+']=plus
    libs['rem']=remainder
    libs['<']=less
    libs['>']=morethan
    libs['=']=equ
    return libs
