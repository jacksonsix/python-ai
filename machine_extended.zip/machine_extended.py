#extend machine with inst procedure,libs,register, controller inst

import machine as basic
import minstructions as assembler
  


def get_operator(cmd):
    return cmd[0]
def get_oprands(cmd):
    return cmd[1:]
def isoperation(inst):
    if type(inst[0]) is list:
        return True
    else:
        return False

def islabel(inst):
    if inst[0]=='label' :
        return True
    else:
        return False
    
    
def make_operation_exp(exp,machine,labels):
    libs = machine('get_libs')
    opname = exp[0][1]
    op = libs.get(opname)
    oprands=[]
    if op is None:
        raise Exception('no such op in lib')
    else:
        for oprand in exp[1:]:
            r = make_prim_exp(oprand,machine,labels)
            oprands.append(r)
    def run_op():
        rs=[]
        for od in oprands:
            rs.append(od())
        result = op(*rs)
        return result
    
    return run_op
    
def make_prim_exp(exp,machine,labels):
    type = exp[0]
    if type =='const':
        def prim_c():
            return float(exp[1])
        return prim_c
    elif type == 'label':
        l = labels.get(exp[1])
        def prim_l():
            return l
        return prim_l
    elif type == 'reg':
        def prim_r():
            return machine('get_reg')(exp[1])
        return prim_r
    else:
        raise Exception('make prim error')

def make_assign(inst,machine,labels):
    oprands= get_oprands(inst)
    targetname = oprands[0]
    val_exp = oprands[1:]
    val_proc=0

    if isoperation(val_exp):        
        val_proc = make_operation_exp(val_exp,machine,labels)
    else:
        val_proc = make_prim_exp(val_exp,machine,labels)
    def assign_reg():
        v = val_proc()
        machine('set_reg')(targetname,v)
        pv = machine('get_reg')('pc')
        machine('set_reg')('pc',pv+1)
        
    return assign_reg

def make_test(inst,machine,labels):
    condition= inst[1:]
    cond_proc=0
    if isoperation(condition):
        cond_proc = make_operation_exp(condition,machine,labels)
        def test_proc(): 
            machine('set_reg')('flag',cond_proc())
            pv = machine('get_reg')('pc')
            machine('set_reg')('pc',pv+1)
        return test_proc    
    else:
        raise Exception('condition error')

def make_branch(inst,machine,labels):
    dest = inst[1]
    if islabel(dest):
        lbl=dest[1]
        next_inst = labels[lbl]
        def branch_proc():
            if machine('get_reg')('flag'):
                machine('set_reg')('pc',next_inst)
            else:
                pv = machine('get_reg')('pc')
                machine('set_reg')('pc',pv+1)
        return branch_proc
    else:
        raise Exception('branch inst error')

    
    
def make_goto(inst,machine,labels):
    dest = inst[1]
    if islabel(dest):
        lbl = dest[1]
        next_inst = labels[lbl]
        def goto_lbl():
            machine('set_reg')('pc',next_inst)
        return goto_lbl    
    else:
        regname = dest[1]
        def goto_reg():
            lb=machine('get_reg')(regname)
            next_inst = labels[lb]
            machine('set_reg')('pc',next_inst)
        return goto_reg
    

def make_save(inst,machine,labels,stack):
    regname = inst[1]
    print(inst)
    def save_proc():
        val = machine('get_reg')(regname)
        stack.append(val)
        pv = machine('get_reg')('pc')
        machine('set_reg')('pc',pv+1)
    return save_proc

    
    

def make_restore(inst,machine,labels,stack):
    regname = inst[1]
    def restore_proc():
        val = stack.pop()
        machine('set_reg')(regname,val)
        pv = machine('get_reg')('pc')
        machine('set_reg')('pc',pv+1)
    return restore_proc    

def make_perform(inst,machine,labels):
    action = inst[1:]
    action_proc = make_operation_exp(action,machine,labels)
    def perform_proc():
        action_proc()
        pv = machine('get_reg')('pc')
        machine('set_reg')('pc',pv+1)
    return perform_proc    
    
    
    
def make_instruction_procedure(inst,labels,machine):
    stack = machine('get_stack')
    runable=[]
    runable.append(inst)
    proc= None

    if(get_operator(inst) =='assign'):
        proc = make_assign(inst,machine,labels)
        runable.append(proc)
        return runable                      
    elif get_operator(inst) =='test':
        proc = make_test(inst,machine,labels)
        runable.append(proc)
        return runable 
    elif get_operator(inst) =='branch':
        proc = make_branch(inst,machine,labels)
        runable.append(proc)
        return runable 
    elif get_operator(inst) =='goto':
        proc = make_goto(inst,machine,labels)
        runable.append(proc)
        return runable 
    elif get_operator(inst) =='save':
        proc = make_save(inst,machine,labels,stack)
        runable.append(proc)
        return runable   
    elif get_operator(inst) =='restore':
        proc = make_restore(inst,machine,labels,stack)
        runable.append(proc)
        return runable   
    elif get_operator(inst) =='perform':
        proc = make_perform(inst,machine,labels)
        runable.append(proc)
        return runable
    else:
        raise Exception('no such instruction')


    
def make_extend(regs,libs,cotrolcode):
    machine = basic.make_machine()
    lables=dict()
    instructions=[]
    procs=[]

    for r in regs:
        machine('add_reg')(r)
        
    machine('add_libs')(libs)
    
    assembler.scanlabel(cotrolcode,instructions,lables)
        
    for it in instructions:
        proc = make_instruction_procedure(it,lables,machine)
        procs.append(proc)
        
    machine('load')(procs)
    machine('loadlabel')(lables)
        
    def dispatch(msg):
        if msg=='run':
            machine('run')
        elif msg=='setreg':
            return machine('set_reg')
        elif msg=='getreg':
            return machine('get_reg')
        elif(msg=='checkcode'):
            return machine('checkcode')()
        elif msg == 'print_snap':
            machine('print_snap')
        else:
            raise Exception('extend machine not support command')

    return dispatch

        
            
            
    
    
