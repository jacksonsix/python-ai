#basic insturctions

#(test (op =) (reg n) (const 1))
#(branch (label base-case)

#(assign n (op -) (reg n) (const 1))

# (goto (label fact-loop))

 #extend with stack
# (save n)
# (restore n)

#command is list, first member is operation
#everythin inside a () is within a command  operation and oprands
#process with type.  test,branch ...
# process recursive,first , rest
#process into struct node.
 

comlist={'test','branch','assign','goto','label','op','reg','const','save','restore','perform'}


def make_nodes(str):
     word=''
     word_list=[]
     skip=False
     count =0
     for ch in str:
         if(ch ==' '):
             if(skip):
                 word += ch
                 continue
             else:
                 word_list.append(word)
                 word=''
         elif(ch =='('):
             if(count ==1):
                 skip=True
                 word += ch
             count += 1    
             
         elif(ch==')'):           
             if(count ==2):
                 skip=False
                 word += ch
             count -=1    

         else:
             word = word + ch
     word_list.append(word)        
     return word_list
            
def make_command(cmdstring):
    command=[]
    t = make_nodes(cmdstring)
    op = t[0]
    oprands = t[1:]
    if(op in comlist):
        command.append(op)
        for para in oprands:
            if(para.find('(') ==-1):
                command.append(para)
            else:
                incom=make_command(para)
                command.append(incom)
            
    else:
        raise Exception('no such instruction')
    return command

def scanlabel(codelist,cmds,labels):
    i=0
    for line in codelist:
        cmd = make_command(line)
        if(cmd[0] == 'label'):
            lbl = cmd[1]
            labels[lbl] = i
        else:
            cmds.append(cmd)
        i += 1



        
